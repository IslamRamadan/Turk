<html>
<head>
         <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">

          
            <link rel="stylesheet" href="{{ asset('front/css/bootstrap.min.css') }}"> 
            <link rel="stylesheet" href="{{ asset('front/css/all.min.css') }}">
	        <link rel="stylesheet" href="{{ asset('front/css/animate.css') }}">
            <link rel="stylesheet" href="{{ asset('front/css/main-style.css') }}">
            <link rel="stylesheet" href="{{ asset('front/css/media.css') }}">    
            <link rel="preconnect" href="https://fonts.gstatic.com">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600&display=swap" rel="stylesheet">
          

            <title>@yield('title')</title>
</head>
<body class="arabic" style="font-family: 'Cairo', sans-serif;" >
       <!----start nav --->
       <div class="container-fluid">
        <div class=" fixed-top row1">
         <div class="container">
        <nav class="navbar navbar-expand-lg " id="start">
          <a  href="{{ url('/') }}" class="logo">
            <img src="{{ asset( $setting_v->logo )}}" class="logo" >
          </a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <i class=" fas fa-bars c-w"></i>
            </button>
         <div class="collapse navbar-collapse d-lg-block d-none" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            
            <li class="nav-item "><a class="nav-link active" href="{{ route('index') }}">الرئيسية</a></li>                    
            <li class="nav-item "><a class="nav-link " href="{{ route('about-us') }}" >من نحن</a></li>
            <li class="nav-item"><a class="nav-link " href="{{ route('services') }}" > خدماتنا </a></li>
            <li class="nav-item"><a class="nav-link " href="{{ route('projects') }}" >أعمالنا </a></li>
                <li class="nav-item"><a class="nav-link " href="{{ route('clients') }}" >عملائنا </a></li>
                <li style="cursor: pointer;color:#fff" class="nav-item dropdown"><a style="color:#fff" class="nav-link c-w " id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">دعاية واعلان </a>

                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="right: 0; text-align: right; width: 250px;">
                    <a target="_blank" class="dropdown-item" href="{{ route('advertising') }}">دعاية واعلان</a>
                    <a target="_blank" class="dropdown-item" href="{{ route('galary') }}">جاليرى</a>
                    @foreach(\App\Models\Post::get() as $one)
                    <a target="_blank"  class="dropdown-item" href="{{ route('advertising.user',$one->id) }}">{{ $one->title }}</a>
                  
                    @endforeach
                  </div>

              </li>
                <li class="nav-item"><a class="nav-link " href="{{ route('contact') }}" >أتصل بنا</a></li>
            @if(app()->getLocale() == 'en')

            <li class="nav-item"><a rel="alternate" class="nav-link "  hreflang="ar" href="{{ LaravelLocalization::getLocalizedURL("ar", null, [], true) }}" >عربي</a></li>
         
            @endif
         
            @if(app()->getLocale() == 'ar')
            <li class="nav-item"><a rel="alternate" class="nav-link "  hreflang="en" href="{{ LaravelLocalization::getLocalizedURL("en", null, [], true) }}" >English</a></li>

         
         
         
            @endif
        </ul> 
         <form class="form-inline">
            <a href="{{ route('price') }}" class="btn btn-w">طلب عرض سعر</a>
         </form>
        </div>
       </nav>
            </div> 
          
    






           <div class="collapse navbar-collapse d-lg-none mobile  " id="navbarSupportedContent">
        
            <ul class="navbar-nav  pad-0 ">
                   <li class="nav-item border-bottom "><a class="nav-link " href="{{ route('index') }}">الرئيسية</a></li>                    
                <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('about-us') }}" >من نحن</a></li>
                <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('services') }}" > خدماتنا </a></li>
                <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('projects') }}" >أعمالنا </a></li>
                    <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('clients') }}" >عملائنا </a></li>
                          <li class="nav-item dropdown border-bottom pad-0"><a class="nav-link c-w " data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
       دعاية واعلان 
                          <i class="fas fa-caret-down float-left"></i>      </a>
              
     <div class="collapse pad-0 mr-0" id="collapseExample" style="background: #fff">
        <ul class="navbar-nav  pad-0 ">
            <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">دعاية واعلان</a></li>
            <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('galary') }}">جاليرى</a></li>
            <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">تصميم هوية الشركات</a></li>
                  <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">خدمات الطباعة</a></li>
                  <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">اليفت واللفتات الاعلانية</a></li>
               <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">الهدايا الدعائية</a></li>
                  <li class="nav-item border-bottom "><a target = "_blank" class="nav-link "href="{{ route('advertising') }}">تجهيزات المعارض</a></li>
                <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">الاعلان التسويقي</a></li>
                  </ul>
     </div>
                
                </li>
                    <li class="nav-item border-bottom"><a class="nav-link "  href="{{ route('contact') }}" >أتصل بنا</a></li>
                @if(app()->getLocale() == 'en')

                <li class="nav-item border-bottom"><a rel="alternate" class="nav-link "  hreflang="ar" href="{{ LaravelLocalization::getLocalizedURL("ar", null, [], true) }}" >عربي</a></li>
             
                @endif
             
                @if(app()->getLocale() == 'ar')
                <li class="nav-item border-bottom"><a rel="alternate" class="nav-link "  hreflang="en" href="{{ LaravelLocalization::getLocalizedURL("en", null, [], true) }}" >English</a></li>
      
             
             
             
                @endif
            </ul> 
          <form class="form-inline">
             <a href="{{ route('price') }}" class="btn btn-w">طلب عرض سعر</a>
          </form>
            </div>









          
          </div></div>
           <a href="tel:+{{ $setting_v->contact_phone}}" id="callnowbutton" class="d-md-none d-block">
            <i class="fas fa-phone"></i>
            أتصل الان </a>
           <!-----end nav ---> 
   
  @yield('content')
 <!----- -->
 <footer class=" text-center">
    <p>جميع الحقوق محفوظة © 2020 | يرصد هذا القالب بواسطة <a href=""> بلو زون</a></p>
    </footer>
     <script src="{{ asset('front/js/jquery-3.3.1.min.js') }}"></script>  
        <script src="{{ asset('front/js/popper.min.js') }}"></script>
        <script src="{{ asset('front/js/bootstrap.min.js') }}"></script>
          <script src="{{ asset('front/js/all.min.js') }}"></script> 
        <script src="{{ asset('front/js/wow.min.js') }}"></script>
     <script>
              new WOW().init();
              </script>
    <script src="{{ asset('front/js/main-js.js') }}"></script>
    @stack('content')
    @include('sweetalert::alert')

</body>
    
</html>