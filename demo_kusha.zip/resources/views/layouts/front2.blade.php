<html>
<head>
         <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" href="{{ asset('front/css/bootstrap.min.css') }}">
            <link rel="stylesheet" href="{{ asset('front/css/all.min.css') }}">
	        <link rel="stylesheet" href="{{ asset('front/css/animate.css') }}">
            <link rel="stylesheet" href="{{ asset('front/css/main-style.css') }}">
            <link rel="stylesheet" href="{{ asset('front/css/media.css') }}">    
            <title>@yield('title')</title>

</head>
<body class="">
     <!----start nav --->
    <div class="container-fluid">
      <div class=" fixed-top row1">
       <div class="container">
      <nav class="navbar navbar-expand-lg " id="start">
        <a  href="{{ route('index') }}" class="logo">
            <img src="{{ asset( $setting_v->logo )}}" class="logo" >
          </a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class=" fas fa-bars c-w"></i>
          </button>
       <div class="collapse navbar-collapse d-lg-block d-none" id="navbarSupportedContent">
         <ul class="navbar-nav mr-auto">
            <li class="nav-item "><a class="nav-link active" href="{{ route('index') }}">home</a></li>                    
            <li class="nav-item "><a class="nav-link " href="{{ route('about-us') }}" > about us</a></li>
            <li class="nav-item"><a class="nav-link " href="{{ route('services') }}" > services </a></li>
            <li class="nav-item"><a class="nav-link " href="{{ route('projects') }}" >projects </a></li>
                <li class="nav-item"><a class="nav-link " href="{{ route('clients') }}" >clients </a></li>
                <li style="cursor: pointer;color:#fff" class="nav-item dropdown"><a style="color:#fff" class="nav-link c-w " id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Advertising </a>

                  <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="right: 0; text-align: right; width: 250px;">
                    <a target="_blank" class="dropdown-item" href="{{ route('advertising') }}"> Advertising</a>
                    <a target="_blank" class="dropdown-item" href="{{ route('galary') }}">gallery</a>
                    @foreach(\App\Models\Post::get() as $one)
                    <a target="_blank"  class="dropdown-item" href="{{ route('advertising.user',$one->id) }}">{{ $one->title_en }}</a>
                  
                    @endforeach
                  </div>

              </li>
            <li class="nav-item"><a class="nav-link " href="{{ route('contact') }}" > contact us</a></li>
  
            @if(app()->getLocale() == 'en')

            <li class="nav-item"><a rel="alternate" class="nav-link "  hreflang="ar" href="{{ LaravelLocalization::getLocalizedURL("ar", null, [], true) }}" >عربي</a></li>
         
            @endif
         
            @if(app()->getLocale() == 'ar')
            <li class="nav-item"><a rel="alternate" class="nav-link "  hreflang="en" href="{{ LaravelLocalization::getLocalizedURL("en", null, [], true) }}" >English</a></li>

         
         
         
            @endif
         </ul> 
       <form class="form-inline">
        <a href="{{ route('price') }}" class="btn btn-w">Request for price</a>
    
       </form>
      </div>
     </nav>
          </div> 
        
 



         <div class="collapse navbar-collapse d-lg-none mobile  " id="navbarSupportedContent">
        
          <ul class="navbar-nav  pad-0 ">
                 <li class="nav-item border-bottom "><a class="nav-link " href="{{ route('index') }}">home</a></li>                    
              <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('about-us') }}" >about us</a></li>
              <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('services') }}" > services </a></li>
              <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('projects') }}" >projects </a></li>
                  <li class="nav-item border-bottom"><a class="nav-link " href="{{ route('clients') }}" >clients </a></li>
                        <li class="nav-item dropdown border-bottom pad-0"><a class="nav-link c-w " data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
                          Advertising
                        <i class="fas fa-caret-down float-left"></i>      </a>
            
   <div class="collapse pad-0 mr-0" id="collapseExample" style="background: #fff">
      <ul class="navbar-nav  pad-0 ">
          <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Advertising</a></li>
          <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('galary') }}">gallery</a></li>
          <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Corporate identity design</a></li>
                <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Printing services</a></li>
                <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Advertising banners</a></li>
             <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Exhibition fixtures</a></li>
                <li class="nav-item border-bottom "><a target = "_blank" class="nav-link "href="{{ route('advertising') }}">Advertising gifts</a></li>
              <li class="nav-item border-bottom "><a target = "_blank" class="nav-link " href="{{ route('advertising') }}">Marketing advertising</a></li>
                </ul>
   </div>
              
              </li>
                  <li class="nav-item border-bottom"><a class="nav-link "  href="{{ route('contact') }}" >  contact us</a></li>
              @if(app()->getLocale() == 'en')

              <li class="nav-item border-bottom"><a rel="alternate" class="nav-link "  hreflang="ar" href="{{ LaravelLocalization::getLocalizedURL("ar", null, [], true) }}" >عربي</a></li>
           
              @endif
           
              @if(app()->getLocale() == 'ar')
              <li class="nav-item border-bottom"><a rel="alternate" class="nav-link "  hreflang="en" href="{{ LaravelLocalization::getLocalizedURL("en", null, [], true) }}" >English</a></li>
    
           
           
           
              @endif
          </ul> 
        <form class="form-inline">
           <a href="{{ route('price') }}" class="btn btn-w">Request for price</a>
        </form>
          </div>
        
        
        
        </div></div>
         <a href="tel:+{{ $setting_v->contact_phone}}" id="callnowbutton" class="d-md-none d-block">
          <i class="fas fa-phone"></i>
         call now</a>
         <!-----end nav ---> 
  @yield('content')
 <!----- -->


 <footer class=" text-center">
    <p>All rights reserved © 2020 | This template is made by <a href=""> bluezone</a></p>
    </footer>
    <script src="{{ asset('front/js/jquery-3.3.1.min.js') }}"></script>  
        <script src="{{ asset('front/js/popper.min.js') }}"></script>
        <script src="{{ asset('front/js/bootstrap.min.js') }}"></script>
          <script src="{{ asset('front/js/all.min.js') }}"></script> 
        <script src="{{ asset('front/js/wow.min.js') }}"></script>
     <script>
              new WOW().init();
              </script>
	<script src="{{ asset('front/js/main-js.js') }}"></script>
</body>
    
</html>
    @stack('content')
    @include('sweetalert::alert')

</body>
    
</html>