@component('mail::message')


طلب جديد.

@component('mail::button', ['url' => ''])
لديك طلب جديد راجع لوحة التحكم
@endcomponent
Thanks,<br>
sair
@endcomponent
