@extends('layouts.dashboard.app2')
@section('title')
@lang("الاعدادات")
@endsection
@section('mo')
@include('flash::message')

    @section('ti')
    الاعدادات
@endsection


        <div class="box box-primary">



            <div class="box-header with-border">





            </div><!-- end of box header -->



            <div class="box-body">

             @if ($setting)


                    <?php
                    $id = $setting->id;
                    $name = $setting->name;
                    $logo = $setting->logo;

                    $about_app = $setting->about_app;
                    $wats= $setting->wats;
                    $tw_link= $setting->tw_link	;
                    $fb_link= $setting->fb_link;
                    $contact_email= $setting->contact_email;
                    $contact_phone= $setting->contact_phone	;
                    $insta_link=$setting->insta_link	;
                    $yt_link=$setting->yt_link	;
                    $status=$setting->status	;
                    $address=$setting->address	;
                    $address_en=$setting->address_en	;
                    $name_en=$setting->name_en	;
			     	$dolar=$setting->dolar	;
                    $about_app_en = $setting->about_app_en;
                     ?>

             @else

                    <?php
                     $id = "";
                    $about_app = "";
                    $wats= "";
                    $name = "";
                    $logo = "";
                    $tw_link= ""	;
                    $fb_link= "";
                    $contact_email= "";
                    $contact_phone= ""	;
                    $insta_link="";
                    $yt_link="";
                    $status="";
                    $address="";
                    $address_en=""	;
                    $name_en=""	;
                    $about_app_en = "";
					$dolar= ""	;

                      ?>

             @endif
                {!! Form::model($setting, ['route' => ['settings.update',$id],
                "method"=>"post",
                "enctype"=>"multipart/form-data"

                ])!!}
                  {{ csrf_field() }}

                  <div class="form-group">
                    <label>@lang('اسم الموقع')</label>
                  {!!  Form::text('name',$name,[
                  "class"=>"form-control"

                  ])!!}
                </div>

                <div class="form-group">
                  <label>@lang('اسم الموقع بالانجيزية')</label>
                {!!  Form::text('name_en',$name_en,[
                "class"=>"form-control"

                ])!!}
              </div>
				
				  <div class="form-group">
                    <label>@lang(' 1 دينار يساوي كم دولار')</label>
                  {!!  Form::text('dolar',$dolar,[
                  "class"=>"form-control"

                  ])!!}
                </div>

                <div class="form-group">
                  <label>@lang('وصف اضافي')</label>
                  <input type="text" name="about_app" class="form-control" value="{{$about_app}}">
                </div>


                <div class="form-group">
                  <label>@lang('وصف اضافي بالانجليزية')</label>
                  <input type="text" name="about_app_en" class="form-control" value="{{$about_app_en}}">
                </div>

                <div class="form-group">
                  <label>@lang(' عنوان الشركة')</label>
                  <input type="text" name="address" class="form-control" value="{{$address}}">
                </div>


                <div class="form-group">
                  <label>@lang(' عنوان الشركة بالانجليزية')</label>
                  <input type="text" name="address_en" class="form-control" value="{{$address_en}}">
                </div>

                <div class="form-group">
                  <label>@lang('شعار الموقع')</label>
                  <div class="row">
                    <div class="col-md-10 col-xs-6">
                    <input type="file" class="form-control" name="img" value="{{ $logo }}">
                  </div>
                    <div class="col-md-2 col-xs-6">
                   
                      
                                         <!-- Button trigger modal-->
<a  class="btn btn-primary" data-toggle="modal" data-target="#modalPush">معاينة الشعار</a>

<!--Modal: modalPush-->
<div class="modal fade" id="modalPush" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
  aria-hidden="true">
  <div class="modal-dialog modal-notify modal-info" role="document">
    <!--Content-->
    <div class="modal-content text-center">
      <!--Header-->
      <div class="modal-header d-flex justify-content-center">
        <p class="heading">شعار الموقع</p>
      </div>

      <!--Body-->
      <div class="modal-body" style="background: #fff">


       <img style="width:300px;height: 300px " src="{{ asset($logo) }}" alt="">

      </div>

      <!--Footer-->
      <div class="modal-footer flex-center">
        <a type="button"  data-dismiss="modal" class="btn btn-danger">اغلاق</a>
      </div>
    </div>
    <!--/.Content-->
  </div>
</div>
<!--Modal: modalPush-->



                  </div>
                  </div>
               
              
              </div>
              <div class="form-group">
                <label>@lang('حالة الموقع')</label>
                 <select name="status" id="" class="form-control">
                   <option 
                    
                 value="">اختر حالة الموقع</option>
                   <option
                   
                   
                   value="1"  
                   @if($status==1)
                   {{ "selected = 'selected'" }}   
                @endif
                   >مفتوح</option>
                   <option value="0"  
                    @if($status==0)
                   {{ "selected = 'selected'" }}    
                   @endif 
                 >مغلق</option>
                  
                </select>            
            </div>

                      <div class="form-group">
                          <label>@lang('site.tw_link')</label>
                        {!!  Form::text('tw_link',$tw_link,[
                      "class"=>"form-control"

                        ])!!}
                      </div>

                      <div class="form-group">
                        <label>@lang('site.fb_link')</label>
                      {!!  Form::text('fb_link',$fb_link,[
                    "class"=>"form-control"

                      ])!!}
                    </div>

                      <div class="form-group">
                        <label>@lang('site.yt_link')</label>
                      {!!  Form::text('yt_link',$yt_link,[
                    "class"=>"form-control"

                      ])!!}
                    </div>


                    <div class="form-group">
                        <label>@lang('site.insta_link')</label>
                      {!!  Form::text('insta_link',$insta_link,[
                    "class"=>"form-control"

                      ])!!}
                    </div>

                    <div class="form-group">
                        <label>@lang('site.contact_phone')</label>
                      {!!  Form::text('contact_phone',$contact_phone,[
                    "class"=>"form-control"

                      ])!!}
                    </div>

                    <div class="form-group">
                      <label>@lang('واتس اب')</label>
                    {!!  Form::text('wats',$wats,[
                  "class"=>"form-control"

                    ])!!}
                  </div>

                    <div class="form-group">
                        <label>@lang('site.contact_email')</label>
                      {!!  Form::text('contact_email',$contact_email,[
                    "class"=>"form-control"

                      ])!!}
                    </div>


                    

                  


                  <div class="form-group">
                      <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> @lang('site.save')</button>
                  </div>

                  {!! Form::close() !!}



                    <!-- Button trigger modal -->


            </div><!-- end of box body -->






        </div>






  

@endsection
