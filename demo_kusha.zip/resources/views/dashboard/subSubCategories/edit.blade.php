@extends('layouts.dashboard.app2')
@section('title')
@lang("تعديل تصنيف")
@endsection
@section('mo')
    



     @section('ti')
     تعديل التصنيف
     @endsection
     @inject('cat','App\Models\Category')
     @inject('subcat','App\Models\SubCategory')


        <div class="box box-primary">




            <div class="box-header">

            </div><!-- end of box header -->
            <div class="box-body">

               @include('partials._errors') 


                  {!! Form::model($category, ['route' => ['subSubCategories.update',$category->id],
                  "method"=>"PUT",'enctype' => 'multipart/form-data'

                  ])!!}
                    {{ csrf_field() }}

                     
                    <div class="form-group">
                        <label>@lang('القسم الرئيسي')</label>
                        {!! Form::select('category_id',$cat->pluck('name','id')->toArray(),null,[
                            'class' => 'form-control form-control-lg' . ($errors->has('category_id') ? ' is-invalid' : null),
                             'id' => 'category',
                             'placeholder' => 'اختر القسم الرئيسي',
                             "required"=>"required"

                         ]) !!}

                    </div>


                    <div class="form-group">
                        <label>@lang('القسم الفرعي')</label>
                        {!! Form::select('subCategory_id',$subcat->pluck('name','id')->toArray(),null,[
                                   'class' => 'form-control form-control-lg' . ($errors->has('subCategory_id') ? ' is-invalid' : null),
                                    'id' => 'records',
                                    'placeholder' => '',
                                    "required"=>"required"
                                ]) !!}

                    </div>





                        <div class="form-group">
                            <label>@lang("التصنيف")</label>
                            <input type="text" name="name" value="{{ $category->name }}" class="form-control" >
                        </div>

                        <div class="form-group">
                            <label>@lang('الترجمة')</label>
                            <input type="text" name="name_en" value="{{ $category->name_en }}"  class="form-control">
                        </div>

                        <div class="form-group">
                            <label>@lang(' الحالة')</label>
                            <select style="width:100%"  name="activity" class="form-control " >
                            <option @if($category->activity == 1 )  {{ "selected" }} @endif value="1">مفعلة</option>
                            <option @if($category->activity == 0 )  {{ "selected" }} @endif value="0">معطلة</option>
                            
                        </select>
                        </div>
                       
  
                        <div class="form-group">
                            <label>@lang('ترتيب الظهور')</label>
                            <input  type="number" name="num" class="form-control" value="{{ $category->num }}">
                        </div>


                    <div class="form-group">
                        <button type="submit" class="btn btn-primary"><i class="fa fa-plus"></i> تعديل </button>
                    </div>

                    {!! Form::close() !!}

            </div><!-- end of box body -->

        </div><!-- end of box -->



        @push('scripts')
        <script>
          
            $("#category").change(function (e) {
                e.preventDefault();
                // get gov
                // send ajax
                // append records
                $("#records").empty();
          
                var category = $("#category").val();
                 
                if (category)
                {
                    $.ajax({
                        url : '{{url('api/v1/subcats')}}',
                        type: 'post',
                        data: {_token:"{{csrf_token()}}",category_id:category},
                        success: function (data) {
        
                            if (data.state == 1)
                            {
        
                                $("#records").empty();
                                $("#records").append('<option value="">اختر قسم فرعي</option>');
                                $.each(data.data, function (index, city) {
                                    $("#records").append('<option value="'+city.id+'">'+city.name+'</option>');
                                });
                            }
                        },
                        error: function (jqXhr, textStatus, errorMessage) { // error callback
                            alert(jqXhr);
                        }
                    });
                }else{
                  //  $("#records").empty();
                    $("#records").append('<option value="">اختر قسم فرعي</option>');
                }
            });
        </script>
        @endpush








@endsection
