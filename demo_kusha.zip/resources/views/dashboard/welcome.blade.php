@extends('layouts.dashboard.app2')
@section('mo')
    
@inject('SubCategory', 'App\Models\SubCategory')
@inject('SubSubCategory', 'App\Models\SubSubCategory')
@inject('Order', 'App\Models\Order')
@inject('Order', 'App\Models\Order')
@inject('Category', 'App\Models\Category')

@inject('Govern', 'App\Models\Govern')
@inject('Item', 'App\Models\Item')
@inject('Brand', 'App\Models\Brand')
@inject('Slider', 'App\Models\Slider')

@inject('User', 'App\User')
@inject('Role', 'App\Role')


     @section('ti')
         الرئيسية
     @endsection



        <div class="box box-primary">





            <section class="content" style="background: #ECF0F5">
                <!-- Info boxes -->
                <div class="row">
                <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-aqua"><i class="fa fa-heart"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">الطلبات</span>
                      <span class="info-box-number"><small>{{ $Order->count() }}</small></span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-red"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">المنتجات</span>
                        <span class="info-box-number">{{ $Item->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->

                  <!-- fix for small devices only -->
                  <div class="clearfix visible-sm-block"></div>

                

                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-yellow"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">الاقسام</span>
                        <span class="info-box-number">{{ $Category->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-aqua"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> الاقسام الفرعية</span>
                        <span class="info-box-number">{{ $SubCategory->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->

                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-yellow"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> الماركات</span>
                        <span class="info-box-number">{{ $Brand->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon  bg-aqua"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">السليدر</span>
                        <span class="info-box-number">{{ $Slider->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->



              



              



                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-yellow"><i class="fa fa-cogs"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">التصنيفات</span>
                        <span class="info-box-number">{{ $SubSubCategory->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->




                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-red"><i class="fa fa-users"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">المشرفين</span>
                        <span class="info-box-number">{{ $User->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->


                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-green"><i class="fa fa-list"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text">رتب المشرفين</span>
                        <span class="info-box-number">{{ $Role->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->



                  <div class="col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box">
                      <span class="info-box-icon bg-green"><i class="fa fa-flag"></i></span>
                      <div class="info-box-content">
                        <span class="info-box-text"> المحافظات</span>
                        <span class="info-box-number">{{ $Govern->count() }}</span>
                      </div><!-- /.info-box-content -->
                    </div><!-- /.info-box -->
                  </div><!-- /.col -->





                </div><!-- /.row -->
              </section><!-- /.content -->


              <div class="row">


                <div class="col-md-12">
                    <!-- LINE CHART -->
                    <div class="box box-info">
                      <div class="box-header with-border">
                        <h3 class="box-title">احصائيات الطلبات </h3>
                        <div class="box-tools pull-right">
                          <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                          <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                      </div>
                      <div class="box-body chart-responsive">
                        <div class="box-body border-radius-none">
                          <div id="chartContainer" style="height: 300px; width: 100%;"></div>

                        </div>
                      </div><!-- /.box-body -->
                    </div><!-- /.box -->
                   </div>





            </div>
		


<br>
            <div class="row">


              <div class="col-md-12">
                <div class="box-header with-border">
                  <h3 class="box-title">اخر الطلبات </h3>
                  <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                    <button class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                  </div>
                </div>
                <div class="box-body">

     <div class="table-responsive">
                    <table class="table table-hover table-bordered  ">

                        <thead>
                        <tr>
                            <th>#</th>
                            <th class="text-center">@lang('الكود')</th>
                            <th class="text-center">@lang('المبلغ')</th>
                            <th class="text-center">@lang('الهاتف')</th>
                            <th class="text-center">@lang('المحافظة')</th>
                            <th class="text-center">@lang('المدينة')</th>
                            <th class="text-center">@lang('العنوان')</th>
                            <th class="text-center">@lang('التاريخ')</th>
                            <th class="text-center">@lang('حالة الطلب')</th>

                            <th class="text-center">@lang('الاجراءت')</th>
                        </tr>
                        </thead>

                        <tbody>
                            @foreach ($orders as $category)


                            <tr>
                                <td>{{$loop->iteration}}</td>
                            <td class="text-center">{{$category->id}}</td>
                            <td class="text-center">{{$category->price}}  د.ك </td>
                            <td class="text-center">{{$category->phone}}</td>
                            <td class="text-center">{{$category->govern}}</td>
                            <td class="text-center">{{$category->city}}</td>
                            <td class="text-center">{{$category->address}}</td>
                            <td class="text-center">{{$category->created_at}}</td>
                            @if ($category->status==1)
                            <td class="text-center"> <div class="alert alert-info">جاري الشحن</div></td>
                            @elseif($category->status==2)
                            <td class="text-center"> <div class="alert alert-danger">تم الشحن</div></td>

                            @elseif($category->status==3)
                            <td class="text-center"> <div class="alert alert-success">تم الاستلام </div></td>
                             @elseif($category->status==4)
                            <td class="text-center"> <div class="alert alert-danger">تم الالغاء</div></td>
                            @else
                            <td class="text-center"> </td>

                              @endif


                           


                                <td class="text-center">
                           @if($category->status!=4)
                                        <a href="{{url(route("orders.get_cancel",$category->id)) }}" class="btn btn-primary btn-sm"><i class="fa fa-close"></i> @lang('')</a>
									@endif
									 <a href="{{url(route("orders.edit",$category->id)) }}" class="btn btn-primary btn-sm"><i class="fa fa-edit"></i> @lang('')</a>
									
                                        <a href="{{url(route("order.item",$category->id)) }}" class="btn btn-success btn-sm"><i class="fa fa-eye"></i> @lang('')</a>

                               
                                <form action="{{url(route("orders.destroy",$category->id)) }}" method="post" style="display: inline-block">
                                    {{ csrf_field() }}
                                    {{ method_field('delete') }}
                                            <button type="submit" class="btn btn-danger delete  btn-sm"><i class="fa  fa-trash"></i> @lang('')</button>
                                        </form><!-- end of form -->

                                </td>
                            </tr>
                            @endforeach

                        </tbody>

                    </table><!-- end of table -->
                </div>
                    
                      <!-- Button trigger modal -->
  
  
              </div><!-- end of box body -->
                 
                 </div>





          </div>



           
              </div><!-- end of box body -->




    
          




@endsection
@push('scripts')
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
  window.onload = function () {
  
  var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
   
    axisX:{
      valueFormatString: "DD MMM"
    },
    axisY: {
      title: "عدد الطلبات",
      scaleBreaks: {
        autoCalculate: true
      }
    },
    data: [{
		type: "line",
		xValueFormatString: "DD MMM",
		color: "#F08080",
		dataPoints: [
      @foreach ($records as $record)
			{ x: new Date({{ $record->year }}, 0, {{ $record->month }}), y: {{ $record->count }} },
     

      @endforeach
		
		]
	}]
});
  chart.render();
  
  }
  //@foreach ($records as $record)
         

// { x: new Date("{{ $record->year }}", 0, "{{ $record->month }}"), y:"{{ $record->count }}" },
 //@endforeach
  </script>
  
@endpush