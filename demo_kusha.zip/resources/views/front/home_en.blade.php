@extends('layouts.front2')

@section('title')
    bluezone-home
@endsection

@section('content')


        <!-----start  --->
        <div class="container-fluid head ">
          <div class="text-right rotate"> <img src="{{ asset('front/img/dot-circle.png') }}" id="image" ></div>
               <div class="abs w-100">
                   <div class="container">
                   <div class="row h-100">
                   <div class="col-md-8 col-12">
                       <br>
                       <h1 sty>{{ $setting_v->name_en }}</h1>

                       <p>{{ $setting_v->about_app_en }}</p>
                       <a href="{{ route('projects') }}" class="btn ">Latest projects <i class="fas fa-arrow-right"></i></a>
                         <!-----   <a href="{{ route('contact') }}" class="btn active d-md-inline d-none">contact us  <i class="fas fa-arrow-right"></i></a> -->
                      <a href="" class=" btn bg-none" data-toggle="modal" data-target="#exampleModal">
                          <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                     Customer reviews
                     </a>
                       </div>
                        <div class="col-md-4 d-md-block d-none">
                       <img src="{{ asset('front/img/mean.png')}}" class=" h-100 w-100 wow fadeInUp text-right">
                       </div>
                   </div>
     </div>
                   
               </div>
           </div>
            <!-----service -->



 

     
    <!-----service -->
    <div class="container-fluid relative video">
    <iframe  frameborder="0" allowfullscreen="1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" title="YouTube video player" width="100%" src="https://www.youtube.com/embed/gPgMltxn-N4?playlist=gPgMltxn-N4&amp;iv_load_policy=3&amp;enablejsapi=1&amp;disablekb=1&amp;autoplay=1&amp;controls=0&amp;showinfo=0&amp;rel=0&amp;loop=1&amp;origin=https%3A%2F%2Fwww.qeematech.net&amp;widgetid=1" id="widget2" class="iframe"></iframe>
        <div class="abs1 w-100 h-100"></div>
         <div class="abs w-100 ">
              <div class="container">
              <div class="row  text-center">
                   <h2 class="col-12">Our services
                  <hr></h2>
                 @foreach ($services_v as  $service)

          <div class="col-md-4 col-sm-6 col-12 wow fadeInDown services">          
  <div class="service">
    <div class="card__face card__face--front">
      <i class="{{ $service->icon }}" style="font-size: 35px;"></i> 
     <h3>  {{ $service->name_en }}</h3>
     </div>
   <div class="card__face card__face--back">
    <h3>{{ $service->name_en }}</h3>
       <a class="btn btn-w" href="{{ route('services') }}" target="_self" title="">More</a>
     </div>
 </div>

     </div>
     @endforeach

          
         
           
          </div>
           
              </div>
</div>
              
          </div>
    </div>



     <!-----project -->
   <div class="container-fluid ">
     <div class="container pad project">
          <div class="row text-center">
            <h2 class="col-12">Our business and our projects
                <hr></h2>
             <p class="col-12">bluezone Company provides the best solutions and offers available for web design and application programming</p>
                 <div class="col-12" id="accordion">            
             <ul  class="pad-0 "  >
               
        <li class="btn btn-light active" data-toggle="collapse" href="#collapse1" role="button" aria-expanded="false" aria-controls="collapse1" > all projects</li>
        @foreach ($categories_v as $category )
        <li class="btn btn-light" data-toggle="collapse" href="#collapse{{$category->id }}" role="button" aria-expanded="false" aria-controls="collapse{{$category->id }}" >{{ $category->category_en }}</li>
        @endforeach
       
                 
            
                </ul>
   <div id="collapse1" class="collapse row show" aria-labelledby="heading1" data-parent="#accordion">

    @foreach (\App\Models\Item::where("activity",1)->orderBy("tag","asc")->limit(12)->get() as $item )
    <div class="col-md-3 col-sm-6 col-12">
      <div class="img-project relative ">
          <img src="{{ asset($item->img) }}" >
         <a   href="{{ route("project.user",$item->id) }}" class="btn btn-light active abs" > {{ $item->name_en }}</a>
        </div>
  </div>
    @endforeach
   
       
   </div>
   @foreach ( $categories_v as $category )

   <div id="collapse{{$category->id }}" class="collapse row " aria-labelledby="heading2" data-parent="#accordion">
    @foreach ( \App\Models\Item::where("activity",1)->where("category_id",$category->id )->limit(4)->get() as $item )
    <div class="col-md-3 col-sm-6 col-12">
             <div class="img-project relative ">
                 <img src="{{ asset($item->img) }}" >
                <a  target="" href="{{ route("project.user",$item->id) }}" class="btn btn-light active abs" > {{ $item->name_en }}</a>
               </div>
         </div>
         @endforeach

           
     </div> 
   @endforeach

    
                  
                  
         </div>
              <div class="col-12"><a href="{{ url('/projects') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i> view all projects </a></div>
        </div>
   </div>
   </div>    




   
	<!-- count--->
    <div class="container-fluid contact text-center pad ">
		<div class="container">
			<div class="row pad">
                <h2 class="col-12 c-w">statistics 
                  <hr></h2>
		 <div class="col-lg-3 col-sm-6 col-12 pad">
             
      <p class="count ">{{ $sta->num1 }}</p> 
      <p class="c-w">{{ $sta->title1_en }}</p>
   </div>
      <div class="col-lg-3 col-sm-6 col-12 pad">
     <p class="count">{{ $sta->num2 }}</p> 
      <p class="c-w">{{ $sta->title2_en }}</p>
   </div>
      <div class="col-lg-3 col-sm-6 col-12 pad">
     <p class="count">{{ $sta->num3 }}</p> 
      <p class="c-w">{{ $sta->title3_en }}</p>
   </div>
      <div class="col-lg-3 col-sm-6 col-12 pad">
     <p class="count">{{ $sta->num4 }}</p> 
      <p class="c-w">{{ $sta->title4_en }}</p>
		</div>
        
		 </div>
		 </div>
     </div>
	    <!----- -->

   <div class="container-fluid ">
     <div class="container pad ">
          <div class="row text-center">
            <h2 class="col-12"> Customer reviews

                <hr></h2>
             <p class="col-12">What did clients say about Bluzone?
</p>
@foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )

                 <div class="col-sm-4 col-12 relative wow fadeInRight" >
                     <img src="{{ asset($owner->img) }}" width="100%" >
                     <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                    <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
               </a>
              </div>
              @endforeach
              
                             <div class="col-12"><a href="{{ url('/clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  view all Customer reviews</a></div>

         </div></div></div>
   

   	




     <!-----contact -->
   <div class="container-fluid contact">
     <div class="container pad ">
          <div class="row text-center">
            <h2 class="col-12"> contact us now
                <hr></h2>
             <p class="col-12">contact to us 24 hours a day and talk to specialized engineers
</p>
                 <div class="col-md-5    col-12" >
                     <div class="box">
                    <a href="tel:{{ $setting_v->contact_phone }}"> {{ $setting_v->contact_phone }}</a>
                        <div class="icon"><i class="fas fa-phone" ></i></div>  
                     </div>
                       <div class="box">
                    <a href="mailto: {{ $setting_v->contact_email }}"> Click to contact us</a>
                        <div class="icon"><i class="fas fa-envelope" ></i></div>  
                     </div>
                       <div class="box">
                    <a href="{{ $setting_v->fb_link }}/?ref=bookmarks"> Bluezone</a>
                        <div class="icon"><i class="fab fa-facebook" ></i></div>  
                     </div>
                      <div class="box">
                    <a href="{{ $setting_v->tw_link }}"> Bluezone</a>
                        <div class="icon"><i class="fab fa-twitter" ></i></div>  
                     </div>
                      <div class="box">
                    <a href="{{ $setting_v->insta_link }}/"> Bluezone</a>
                        <div class="icon"><i class="fab fa-instagram" ></i></div>  
                     </div>
                      <div class="box">
                            <div class="icon"><i class="fab fa-youtube" ></i></div>
                    <a href="{{ $setting_v->yt_link }}?view_as=subscriber"> Bluezone</a>
                        
                     </div>
                       <div class="box">
                            <div class="icon"><i class="fas fa-home" ></i></div> 
                    <a > {{ $setting_v->address_en }}</a>
                        
                     </div>
              </div>
              <div class="col-md-7 col-12" >
            <form method="post" action="{{ route('contact.user') }}" class=" row">
              @csrf
                  <div class="col-md-6">
                          <input name="name" required type="text" placeholder="name" class="form-control">
                      </div>
                 <div class="col-md-6">
                          <input name="company" required  type="text" placeholder="company" class="form-control">
                      </div>
                 <div class="col-md-6">
                          <input name="email" required type="text" placeholder=" E-mail" class="form-control">
                      </div>
                 <div class="col-md-6">
                          <input name="address" required type="text" placeholder=" Company Address" class="form-control">
                      </div>
                 <div class="col-md-6">
                          <input name="phone" required type="text" placeholder="Phone / Please enter the country code" class="form-control">
                      </div>
                <div class="col-md-6">
                          <input name="wats" type="text" required placeholder="Whatsapp number / for easy communication" class="form-control">
                      </div>
                         <div class="col-md-12" >
                             <input name="title" required type="text" placeholder="project" class="form-control">
                     </div>
                      <div class="col-md-12">
                            <textarea name="content" required class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="the message"></textarea>
                     </div>
                                       <div class="col-md-12">
                                           <button type="submit" value="" class="btn-w btn">send</button> 
                </div>
                </form>
              </div></div></div></div>
     <!----- -->

   
   

     <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
                     <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

<!--


-->



@endsection