@extends('layouts.front')

@section('title')
    بلوزون-طلب-سعر
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


    





         
     <!-----contact -->
     <div class="container-fluid contact">
        <div class="container pad ">
             <div class="row text-center">
               <h2 class="col-12"> طلب عرض سعر
                    <hr></h2>
                 <p class="col-12">توصل معنا علي مدار ال 24 ساعة وتحدث مع مهندسين مختصيين
  </p>
                 <div class=" col-md-8" >
               <form class=" row" method="post" action="{{ route('contact.user') }}">
              @csrf
                <input type="hidden" name="cart" value="cart">
                     <div class="col-md-6">
                             <input type="text" required name="name" placeholder="الأسم" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="company"  placeholder="الشركة" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="email"  placeholder="البريد الالكتروني" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="address"  placeholder="عنوان الشركة" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="phone"  placeholder="الهاتف / برجاء كتابة كود البلد" class="form-control">
                         </div>
                   <div class="col-md-6">
                             <input type="text" required name="wats"  placeholder="رقم الواتس / لسهولة التواصل" class="form-control">
                         </div>
                   <div class="col-md-6">
                             <input type="text" required name="money"  placeholder="الميزانية" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <select class="form-control" required name="currency" >
                              <option class="form-control">KWD</option>  
                                 <option class="form-control">EGP</option>
                                 <option class="form-control">USD</option>
                     </select>
                         </div>
                            <div class="col-md-12">
                                <input required name="title"  type="text" placeholder="الموضوع" class="form-control">
                        </div>
                         <div class="col-md-12">
                               <textarea required name="msg"  name="textarea-234" class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="نص الرساله"></textarea>
                        </div>
                                          <div class="col-md-12">
                                              <button type="submit" value="" class="btn-w btn">أرسال</button> 
                   </div>
                   </form>
                 </div>
               <div class="col-md-4 d-md-block d-none">
                    <img src="{{ asset('front/img/mean.png') }}" class=" h-100 w-100 wow fadeInUp text-right">
                    </div>
            </div></div></div>
   
   
   

            <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
              <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection