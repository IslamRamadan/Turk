@extends('layouts.front')

@section('title')
    بلوزون-من-نحن
@endsection

@section('content')
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
</div>
           <!-----about -->
    <div class="container-fluid ">
        <div class="container pad">
            <div class="row pad">
                <div class="col-md-6">
                    <h5 class=" main-color">9 سنوات من الخبرة في مجال البرمجيات</h5>
                    <h2 class="">
                        لماذا بلوزون
                    </h2>
                    <hr class="float-right"><br><br>
                    <p>هل تبحث عن شركة مبدعة تكرس كل جهودها من أجل نجاحك ونجاح موقعك الإلكتروني؟ إذا كانت الإجابة بنعم، لا تقلق نحن هنا لخدمتك شركة بلوزون شريك إلكتروني رائع للوصول للنجاح الذي تسعى له ، من خلال خبرتنا الطويلة في مجال التسويق الإلكتروني والحلول
                        الرقمية فإننا نضمن لك العمل مع فريق من المحترفين في عالم الإنترنت</p>
                    <p>تُعد شركتنا واحدة من أفضل الشركات الرائدة في مجال تطوير وتصميم المواقع الإلكترونية في الكويت والعالم العربي . ولدينا خبرات طويلة في مجال التسويق الإلكتروني واستضافة المواقع وبرمجة التطبيقات للأندرويد والايفون وال erp systems</p>
                    <a href="{{ route('price') }}" class="btn btn-light active">  طلب عرض سعر</a>

                </div>
                <div class="col-md-6 text-center">
                    <img src="{{ asset('front/img/about.jpg') }}" width="80%">
                    <br><br>
                </div>
               
                @foreach ($services_v as  $service)
                <div class="col-md-3 col-sm-6 col-12  wow fadeInDown">
                    <div class="service about">
                        <div class="card__face card__face--front ">
                            <i class=" {{ $service->icon }} main-color" style="font-size: 35px;"></i>
                            <h3> {{ $service->name }}</h3>
                        </div>
                        <div class="card__face card__face--back ">
                            <h3>{{ $service->name }}</h3>
                            <p>نمتلك خبرة أكثر من 10 سنوات في {{ $service->name }}</p>
                        </div>
                    </div>

                </div>
               
               @endforeach

            </div>
        </div>
    </div>
    <!-----about -->
    <div class="container-fluid ">
        <div class="row pad">
            <div class="col-md-6 about-us">
                <div class="container pad">
                    <h5>شركة بلوزن</h5>
                    <h2 class="">
                        من نحن
                    </h2>
                    <hr class="float-right"><br><br>
                    <p>نحن فريق من المتخصصين في التسويق الإلكتروني نعمل فى الكويت والوطن العربي</p>

                    <div id="accordion">
                        <div class="card">
                            <div class="card-header" id="headingOne">

                                <button class="btn btn-link w-100 text-right" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <h3><i class=" fas fa-eye"></i> رؤيتنا
            <i class=" fas fa-caret-down float-left"></i>
            </h3>
        </button>

                            </div>

                            <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordion">
                                <div class="card-body">
                                    <p>رؤيتنا هي توفير خدمات احترافية لعملائنا، والعمل على التطوير المستمر في قدراتنا و امكاناتنا، لتحقيق رسالتنا في تنفيذ مشروعاتنا بإتقان
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingTwo">
                                <button class="btn btn-link w-100 text-right" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseOne">
       <h3><i class=" fas fa-eye"></i> رسالتنا
            <i class=" fas fa-caret-down float-left"></i>
             </h3></button>
                            </div>
                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
                                <div class="card-body">
                                    <p>تنفيذ المشروعات بحرفية وتحقيق رؤية العميل في موقعه الإلكتروني الجديد أو خدمات التسويق التي نُقدمها له بما يتناسب مع قواعد التسويق وسلوك المُستهلك</p>
                                </div>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-header" id="headingThree">
                                <button class="btn btn-link w-100 text-right" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseOne">
       <h3><i class=" fas fa-eye"></i> أهدافنا
            <i class=" fas fa-caret-down float-left"></i>
            </h3>
        </button>
                            </div>
                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
                                <div class="card-body">
                                    <p>اهدافنا ان نحظى بثقة عملائنا من خلال رضاهم عن خدماتنا التى نقدمها لهم بكل حب ومن ثم تتسع دائرة عملائنا يوما بعد يوم ونكون دوما في المقدمة</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 relative pad-0 text-center">
                <img src="{{ asset('front/img/about-video-img.jpg') }}" width="100%">
                <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                    <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                </a>

            </div>
        </div>
    </div>
    <!----- -->






   <!-- count--->
<div class="container-fluid contact text-center pad ">
    <div class="container">
      <div class="row pad">
                <h2 class="col-12 c-w">الاحصائيات 
                  <hr></h2>
     <div class="col-lg-3 col-sm-6 col-12 pad">
             
      <p class="count ">{{ $sta->num1 }}</p> 
       <p class="c-w">{{ $sta->title1 }}</p>
    </div>
       <div class="col-lg-3 col-sm-6 col-12 pad">
      <p class="count">{{ $sta->num2 }}</p> 
       <p class="c-w">{{ $sta->title2 }}</p>
    </div>
       <div class="col-lg-3 col-sm-6 col-12 pad">
      <p class="count">{{ $sta->num3 }}</p> 
       <p class="c-w">{{ $sta->title3 }}</p>
    </div>
       <div class="col-lg-3 col-sm-6 col-12 pad">
      <p class="count">{{ $sta->num4 }}</p> 
       <p class="c-w">{{ $sta->title4 }}</p>
    </div>
        
     </div>
     </div>
     </div>
      <!----- -->



   



   <div class="container-fluid ">
     <div class="container pad ">
          <div class="row text-center">
            <h2 class="col-12"> آراء العملاء
                 <hr></h2>
              <p class="col-12">ماذا قال العملاء عن بلوزون ؟
</p>
@foreach ($owners_v as $owner )

                 <div class="col-sm-4 col-12 relative wow fadeInRight" >
                     <img src="{{ asset($owner->img) }}" width="100%" >
                     <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                    <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
               </a>
              </div>
              @endforeach
              
                             <div class="col-12"><a href="" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  عرض كـــل آراء العملاء</a></div>

         </div></div></div>




        <!-----contact -->
   <div class="container-fluid contact">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> أتصل بنا الان
                <hr></h2>
             <p class="col-12">توصل معنا علي مدار ال 24 ساعة وتحدث مع مهندسين مختصيين
</p>
                <div class="col-md-5 col-12" >
                    <div class="box">
                   <a style=""  href="tel:{{ $setting_v->contact_phone }}"> {{ $setting_v->contact_phone }}</a>
                       <div class="icon"><i class="fas fa-phone" ></i></div>  
                    </div>

                      <div class="box">
                   <a href="mailto: {{ $setting_v->contact_email }}"> اضغط للتواصل معنا</a>
                       <div class="icon"><i class="fas fa-envelope" ></i></div>  
                    </div>


                      <div class="box">
                   <a href="{{ $setting_v->fb_link }}/?ref=bookmarks"> Bluezone</a>
                       <div class="icon"><i class="fab fa-facebook" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->tw_link }}"> Bluezone</a>
                       <div class="icon"><i class="fab fa-twitter" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->insta_link }}/"> Bluezone</a>
                       <div class="icon"><i class="fab fa-instagram" ></i></div>  
                    </div>
                     <div class="box">
                           <div class="icon"><i class="fab fa-youtube" ></i></div>
                   <a href="{{ $setting_v->yt_link }}?view_as=subscriber"> Bluezone</a>
                       
                    </div>
                      <div class="box">
                           <div class="icon"><i class="fas fa-home" ></i></div> 
                   <a > {{ $setting_v->address }}</a>
                       
                    </div>
             </div>
             <div class="col-md-7 col-12" >
           <form method="post" action="{{ route('contact.user') }}" class=" row">
             @csrf
                 <div class="col-md-6">
                         <input name="name" required type="text" placeholder="الأسم" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="company" required  type="text" placeholder="الشركة" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="email" required type="text" placeholder="البريد الالكتروني" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="address" required type="text" placeholder="عنوان الشركة" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="phone" required type="text" placeholder="الهاتف / برجاء كتابة كود البلد" class="form-control">
                     </div>
               <div class="col-md-6">
                         <input name="wats" type="text" required placeholder="رقم الواتس / لسهولة التواصل" class="form-control">
                     </div>
                        <div class="col-md-12" >
                            <input name="title" required type="text" placeholder="الموضوع" class="form-control">
                    </div>
                     <div class="col-md-12">
                           <textarea name="content" required class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="نص الرساله"></textarea>
                    </div>
                                      <div class="col-md-12">
                                          <button type="submit" value="" class="btn-w btn">أرسال</button> 
               </div>
               </form>
             </div></div></div></div>
    <!----- -->
   
   
   

    <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
                       <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection