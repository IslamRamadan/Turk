@extends('layouts.front')

@section('title')
بلوزون-دعاية-واعلان
@endsection

@section('content')
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
</div>
        
      <!----- -->
      <div class="container-fluid bg-light gallary">
        <div class="container pad ">
             <div class="row ">
                         <h2 class="col-12 main-color text-center">بعض من اعمالنا  <hr></h2>
                         @foreach(\App\Models\Galary::get() as $one )
                               
                 <div class="  col-md-3 ">
                     <img src="{{ asset($one->img) }}" class="card-img-top  w-100 pad"  data-toggle="modal" data-target="#exampleModal">
                           </div>

                           @endforeach
                
                   
                         
                 </div>
                 </div>
            </div>
       <!----- -->


              <!-- Modal -->
              <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important;height: 100vh">
                  <div class="modal-content"  style=" background: #04040480!important;border: none!important">
                      <br>
                   <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
                       <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
                      </button>
                    <div class="modal-body">
                        <br>
                      <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                <div class="carousel-inner">
            
                  @php
                    $i = 0;  
                  @endphp
            
            @foreach(\App\Models\Galary::get() as $one )
            
                  <div class="carousel-item  @if($i==0)   active   @endif text-center">
                <img src="{{ asset($one->img) }}" class="card-img-top  " style="width:80%; height: 80vh" >
                    </div>
               
                    @php
                      $i++ ;  
                    @endphp
                    @endforeach
                 
                  
                </div>
                <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
                  <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                  <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
                  <span class="carousel-control-next-icon" aria-hidden="true"></span>
                  <span class="sr-only">Next</span>
                </a>
              </div>
                    </div>
                   
                  </div>
                </div>
              </div>
               
   

  <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
    <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
 

@endsection