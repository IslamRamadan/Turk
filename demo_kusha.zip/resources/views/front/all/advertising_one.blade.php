@extends('layouts.front')

@section('title')
    بلوزون-دعاية-واعلان
@endsection

@section('content')

<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
</div>
        
     <!----- -->
     <div class="container-fluid bg-light">
        <div class="container pad ">
                         <h2 class="col-12 main-color text-center">{{ $record->title}}</h2>
                         <hr>
    <div class="card">
                       <div class="row ">
                 <div class="  col-md-6 pad-0">
                     <img src="{{ asset($record->img) }}" class="card-img-top  w-100"  >
                           </div>
                      <div class="card-body border-bottom col-md-6">
                
                          <h4 class="main-color">{{ $record->title }}</h4>
                              <p> {!! htmlspecialchars_decode( $record->content)  !!}
  
  </p>
                         
                 </div>
                 </div>
            </div>
          </div></div>
       <!----- -->
   

       <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
        <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
 

@endsection