@extends('layouts.front')

@section('title')
    بلوزون-تفاصيل-العمل
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


    
    <!----- -->
    <div class="container-fluid bg-light">
        <div class="container pad ">
                 <div class="card  " >
                     <div class="row">
                      <div class=" col-md-6 col-12  ">
                          <br><br>
                          
                <h2>تفاصيل المشروع</h2>
                          <hr class="float-right">
                          <div style="clear: both"></div>
                          
                          <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-sun"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>فكرة الموقع</h4>
                          <p> {!! htmlspecialchars_decode( $project->text1 )  !!}
                               
                              </div></div>
                                    <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-database"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>المطلوب تنفيذه</h4>
                          <p> {!! htmlspecialchars_decode( $project->text2 )  !!}
                          </div></div>
                           <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-clock"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>التنفيذ و النتيجة</h4>
                          <p> {!! htmlspecialchars_decode( $project->text3 )  !!}
                          </div></div>
                   
                     </div>
                     <div class="col-md-6 col-12 pad-0">
                     <img src="{{ asset($project->img) }}" class="  w-100"  >
                         </div>
                      <ul  class=" col-12 text-center pad"  >

                        @if($project->link !="")
           <li class="btn btn-light " ><a href="{{ $project->link }}" >مشاهدة الموقع</a></li>
                       @endif

                       @if($project->ios !="")
           <li class="btn btn-light"  ><a href="{{ $project->ios }}" > تحميل من app store <i class="fab fa-apple" style="font-size: 25px"></i></a></li>
                     @endif

                     @if($project->android !="")
                    <li class="btn btn-light" ><a href="{{ $project->android }}" > تحميل من google play   <i class="fab fa-android" style="font-size: 25px"></i></a></li>
                    @endif

                    <li class="btn btn-light" ><a href="{{ route('price') }}" > عرض سعر</a></li>
                        
                 </ul>
                     </div>
                 </div>
                 </div>
            </div>
          
      <!----- -->


       <!----- -->

   <div class="container-fluid ">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> آراء العملاء
                <hr></h2>
             <p class="col-12">ماذا قال العملاء عن بلوزون ؟
</p>
@foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )

                <div class="col-sm-4 col-12 relative wow fadeInRight" >
                    <img src="{{ asset($owner->img) }}" width="100%" >
                    <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                   <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
              </a>
             </div>
             @endforeach
             
                            <div class="col-12"><a href="{{ route('clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  عرض كـــل آراء العملاء</a></div>

        </div></div></div>




         
    
   
   

        <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
          <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection