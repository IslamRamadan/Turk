@extends('layouts.front')

@section('title')
    بلوزون-اتصل-بنا
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


   
     



   <!-----contact -->
   <div class="container-fluid ">
    <div class="container pad ">
         <div class="row text-center">
           <h4 class="col-12 main-color">أتصل بنا 
             </h4>
           <h2 class="col-12"> 
              خدمة 24 ساعة
               <hr></h2>
             <p class="col-12">نحن هنا للمساعدة. كل ما تريد مناقشته، نحب أن نسمع عن أهداف عملك ويمكننا توفير استراتيجيات
                 <br>
                 تسويقية لمساعدتك على تحقيق هذه الاهدف وتطوير اعمالك.
</p>
                <div class="col-sm-4 col-12" >
                    <div class="card">
                        <p><i class="fas fa-home main-color" style="font-size: 40px;"></i></p>   
                        <h2 >العنوان الرئيسي</h2>
                        <p >{{ $setting_v->address }}</p>
                    </div>
                    </div>
              <div class="col-sm-4 col-12" >
                    <div class="card">
                            <p><i class="fas fa-clock main-color" style="font-size: 40px;"></i></p>   
                        <h2 >مواعيد العمل</h2>
                        <p >تواصل معنا علي مدار ال 24 ساعة </p>
                    </div>
                    </div>
              <div class="col-sm-4 col-12" >
                    <div class="card">
                        <p><i class="fas fa-envelope main-color" style="font-size: 40px;"></i></p>   
                        <h2 >البريد الالكتروني</h2>
                        <p >{{ $setting_v->contact_email }}</p>
                    </div>
                    </div>
             </div>
        
        </div></div>

        


<!-- count--->
<div class="container-fluid contact text-center pad ">
  <div class="container">
    <div class="row pad">
              <h2 class="col-12 c-w">الاحصائيات 
                <hr></h2>
   <div class="col-lg-3 col-sm-6 col-12 pad">
           
    <p class="count ">{{ $sta->num1 }}</p> 
     <p class="c-w">{{ $sta->title1 }}</p>
  </div>
     <div class="col-lg-3 col-sm-6 col-12 pad">
    <p class="count">{{ $sta->num2 }}</p> 
     <p class="c-w">{{ $sta->title2 }}</p>
  </div>
     <div class="col-lg-3 col-sm-6 col-12 pad">
    <p class="count">{{ $sta->num3 }}</p> 
     <p class="c-w">{{ $sta->title3 }}</p>
  </div>
     <div class="col-lg-3 col-sm-6 col-12 pad">
    <p class="count">{{ $sta->num4 }}</p> 
     <p class="c-w">{{ $sta->title4 }}</p>
  </div>
      
   </div>
   </div>
   </div>
    <!----- -->






        <div class="container-fluid ">
          <div class="container pad ">
               <div class="row text-center">
                 <h2 class="col-12"> آراء العملاء
                      <hr></h2>
                   <p class="col-12">ماذا قال العملاء عن بلوزون ؟
     </p>
     @foreach ($owners_v as $owner )
     
                      <div class="col-sm-4 col-12 relative wow fadeInRight" >
                          <img src="{{ asset($owner->img) }}" width="100%" >
                          <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                         <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                    </a>
                   </div>
                   @endforeach
                   
     
              </div></div></div>
  






         
      <!-----contact -->
   <div class="container-fluid contact">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> أتصل بنا الان
                <hr></h2>
             <p class="col-12">توصل معنا علي مدار ال 24 ساعة وتحدث مع مهندسين مختصيين
</p>
                <div class="col-md-5 col-12" >
                    <div class="box">
                   <a style=""  href="tel:{{ $setting_v->contact_phone }}"> {{ $setting_v->contact_phone }}</a>
                       <div class="icon"><i class="fas fa-phone" ></i></div>  
                    </div>

                      <div class="box">
                   <a href="mailto: {{ $setting_v->contact_email }}"> اضغط للتواصل معنا</a>
                       <div class="icon"><i class="fas fa-envelope" ></i></div>  
                    </div>


                      <div class="box">
                   <a href="{{ $setting_v->fb_link }}/?ref=bookmarks"> Bluezone</a>
                       <div class="icon"><i class="fab fa-facebook" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->tw_link }}"> Bluezone</a>
                       <div class="icon"><i class="fab fa-twitter" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->insta_link }}/"> Bluezone</a>
                       <div class="icon"><i class="fab fa-instagram" ></i></div>  
                    </div>
                     <div class="box">
                           <div class="icon"><i class="fab fa-youtube" ></i></div>
                   <a href="{{ $setting_v->yt_link }}?view_as=subscriber"> Bluezone</a>
                       
                    </div>
                      <div class="box">
                           <div class="icon"><i class="fas fa-home" ></i></div> 
                   <a > {{ $setting_v->address }}</a>
                       
                    </div>
             </div>
             <div class="col-md-7 col-12" >
           <form method="post" action="{{ route('contact.user') }}" class=" row">
             @csrf
                 <div class="col-md-6">
                         <input name="name" required type="text" placeholder="الأسم" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="company" required  type="text" placeholder="الشركة" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="email" required type="text" placeholder="البريد الالكتروني" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="address" required type="text" placeholder="عنوان الشركة" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="phone" required type="text" placeholder="الهاتف / برجاء كتابة كود البلد" class="form-control">
                     </div>
               <div class="col-md-6">
                         <input name="wats" type="text" required placeholder="رقم الواتس / لسهولة التواصل" class="form-control">
                     </div>
                        <div class="col-md-12" >
                            <input name="title" required type="text" placeholder="الموضوع" class="form-control">
                    </div>
                     <div class="col-md-12">
                           <textarea name="content" required class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="نص الرساله"></textarea>
                    </div>
                                      <div class="col-md-12">
                                          <button type="submit" value="" class="btn-w btn">أرسال</button> 
               </div>
               </form>
             </div></div></div></div>
    <!----- -->

   
   
   
   

    <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
      <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection