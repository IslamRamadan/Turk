@extends('layouts.front2')

@section('title')
    bluezone-about-us
@endsection

@section('content')
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
</div>
           <!-----about -->
    <div class="container-fluid ">
        <div class="container pad">
            <div class="row pad">
                <div class="col-md-6">
                    <h5 class=" main-color">9 years of experience in the software field</h5>
                   <h2 class="">
Why bluezone                       </h2>
                <hr class="float-left"><br><br>
                <p>Are you looking for a creative company dedicated to your success and the success of your website? If the answer is yes, do not worry, we are here to serve you, a valuable tech company, a wonderful electronic partner to reach the success you seek, through our long experience in the field of e-marketing and digital solutions, we guarantee you to work with a team of professionals in the world of the Internet
                </p>
                
                <p>Our company is considered one of the best leading companies in the field of web development and design in Egypt and the Arab world. We have long experiences in e-marketing, web hosting and application programming for Android, iPhone and ERP systems</p>
                    <a href="{{ route('price') }}" class="btn btn-light active"> Request for price</a>

                </div>
                <div class="col-md-6 text-center">
                    <img src="{{ asset('front/img/about.jpg') }}" width="80%">
                    <br><br>
                </div>
               
                @foreach ($services_v as  $service)
                <div class="col-md-3 col-sm-6 col-12  wow fadeInDown">
                    <div class="service about">
                        <div class="card__face card__face--front ">
                            <i class=" {{ $service->icon }} main-color" style="font-size: 35px;"></i>
                            <h3> {{ $service->name_en }}</h3>
                        </div>
                        <div class="card__face card__face--back ">
                            <h3>{{ $service->name }}</h3>
                            <p>نمتلك خبرة أكثر من 10 سنوات في {{ $service->name }}</p>
                        </div>
                    </div>

                </div>
               
               @endforeach

            </div>
        </div>
    </div>
     <!-----about -->
     <div class="container-fluid ">
        <div class="row pad">
            <div class="col-md-6 about-us">
                 <div class="container pad">  
             <h5 >bluezone</h5>
                   <h2 class="">
            about us
                       </h2>
                <hr class="float-left"><br><br>
                <p>We are a team of digital marketing specialists working in Egypt and the Arab world</p>
                
                <div id="accordion">
  <div class="card">
    <div class="card-header" id="headingOne">

        <button class="btn btn-link w-100 text-left" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            <h3><i class=" fas fa-eye"></i> Our vision
            <i class=" fas fa-caret-down float-right"></i>
            </h3>
        </button>
   
    </div>

    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordion">
      <div class="card-body">
      <p>Our vision is to provide professional services to our clients, and to work on continuous development in our capabilities and capabilities, to achieve our mission in implementing our projects perfectly.
</p>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
         <button class="btn btn-link w-100 text-left" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseOne">
       <h3><i class=" fas fa-eye"></i> Our Mission
            <i class=" fas fa-caret-down float-right"></i>
             </h3></button>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
      <div class="card-body">
       <p>Professional implementation of projects and achieving the customer's vision in his new website or the marketing services that we provide to him in accordance with the marketing rules and consumer behavior</p>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
         <button class="btn btn-link w-100 text-left" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseOne">
       <h3><i class=" fas fa-eye"></i> Our goals
            <i class=" fas fa-caret-down float-right"></i>
            </h3>
        </button>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
      <div class="card-body">
       <p>Our goals are to gain the confidence of our customers through their satisfaction with our services that we offer them with love, and then the circle of our customers is expanding day after day and we are always at the forefront</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 relative pad-0 text-center">
                <img src="{{ asset('front/img/about-video-img.jpg') }}" width="100%">
                <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                    <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                </a>

            </div>
        </div>
    </div>
    <!----- -->






    <!-- count--->
    <div class="container-fluid contact text-center pad ">
      <div class="container">
        <div class="row pad">
                  <h2 class="col-12 c-w">statistics 
                    <hr></h2>
       <div class="col-lg-3 col-sm-6 col-12 pad">
               
        <p class="count ">{{ $sta->num1 }}</p> 
        <p class="c-w">{{ $sta->title1_en }}</p>
     </div>
        <div class="col-lg-3 col-sm-6 col-12 pad">
       <p class="count">{{ $sta->num2 }}</p> 
        <p class="c-w">{{ $sta->title2_en }}</p>
     </div>
        <div class="col-lg-3 col-sm-6 col-12 pad">
       <p class="count">{{ $sta->num3 }}</p> 
        <p class="c-w">{{ $sta->title3_en }}</p>
     </div>
        <div class="col-lg-3 col-sm-6 col-12 pad">
       <p class="count">{{ $sta->num4 }}</p> 
        <p class="c-w">{{ $sta->title4_en }}</p>
      </div>
          
       </div>
       </div>
       </div>
        <!----- -->



   



      <div class="container-fluid ">
        <div class="container pad ">
             <div class="row text-center">
               <h2 class="col-12"> Customer reviews
   
                   <hr></h2>
                <p class="col-12">What did clients say about Bluzone?
   </p>
   @foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )
   
                    <div class="col-sm-4 col-12 relative wow fadeInRight" >
                        <img src="{{ asset($owner->img) }}" width="100%" >
                        <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                       <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                  </a>
                 </div>
                 @endforeach
                 
                                <div class="col-12"><a href="{{ route('clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  view all Customer reviews</a></div>
   
            </div></div></div>
      




        <!-----contact -->
   <div class="container-fluid contact">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> contact us now
               <hr></h2>
            <p class="col-12">contact to us 24 hours a day and talk to specialized engineers
</p>
                <div class="col-md-5    col-12" >
                    <div class="box">
                   <a href="tel:{{ $setting_v->contact_phone }}"> {{ $setting_v->contact_phone }}</a>
                       <div class="icon"><i class="fas fa-phone" ></i></div>  
                    </div>
                      <div class="box">
                   <a href="mailto: {{ $setting_v->contact_email }}"> Click to contact us</a>
                       <div class="icon"><i class="fas fa-envelope" ></i></div>  
                    </div>
                      <div class="box">
                   <a href="{{ $setting_v->fb_link }}/?ref=bookmarks"> Bluezone</a>
                       <div class="icon"><i class="fab fa-facebook" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->tw_link }}"> Bluezone</a>
                       <div class="icon"><i class="fab fa-twitter" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->insta_link }}/"> Bluezone</a>
                       <div class="icon"><i class="fab fa-instagram" ></i></div>  
                    </div>
                     <div class="box">
                           <div class="icon"><i class="fab fa-youtube" ></i></div>
                   <a href="{{ $setting_v->yt_link }}?view_as=subscriber"> Bluezone</a>
                       
                    </div>
                      <div class="box">
                           <div class="icon"><i class="fas fa-home" ></i></div> 
                   <a > {{ $setting_v->address_en }}</a>
                       
                    </div>
             </div>
             <div class="col-md-7 col-12" >
           <form method="post" action="{{ route('contact.user') }}" class=" row">
             @csrf
                 <div class="col-md-6">
                         <input name="name" required type="text" placeholder="name" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="company" required  type="text" placeholder="company" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="email" required type="text" placeholder=" E-mail" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="address" required type="text" placeholder=" Company Address" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="phone" required type="text" placeholder="Phone / Please enter the country code" class="form-control">
                     </div>
               <div class="col-md-6">
                         <input name="wats" type="text" required placeholder="Whatsapp number / for easy communication" class="form-control">
                     </div>
                        <div class="col-md-12" >
                            <input name="title" required type="text" placeholder="project" class="form-control">
                    </div>
                     <div class="col-md-12">
                           <textarea name="content" required class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="the message"></textarea>
                    </div>
                                      <div class="col-md-12">
                                          <button type="submit" value="" class="btn-w btn">send</button> 
               </div>
               </form>
             </div></div></div></div>
    <!----- -->
   
   

    <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
      <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection