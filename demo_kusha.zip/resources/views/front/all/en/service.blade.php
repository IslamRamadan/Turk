@extends('layouts.front2')

@section('title')
    bluezone-serrvics
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


       <!-----service -->
       <div class="container-fluid bg-light">
        <div class="container pad">
        <div class="row  text-center">
            <h3 class="col-12 main-color">Our services</h3>
            <h2 class="col-12">
All the services you need in one place, in safe hands
                <hr></h2>
           <p class="col-12">Since 2011, we have been one of the largest software companies in kuwait... more than 1000 customers and thousands of solutions and services provided.
</p>
@foreach ($services_v as  $service)
  <div class="col-md-4 col-sm-6 col-12  wow fadeInDown">          
<div class="card text-center">
<div class="pad">
<span class="icon">
     <i class="{{ $service->icon }} main-color" style="font-size: 35px;  "></i> 
    </span>
</div>
    <h3 class="main-color">{{ $service->name_en }}</h3>
    <p class="card-text">{{ $service->text_en }}</p>
    <a href="{{ route('projects') }}" class="service-btn"><i class="fas fa-arrow-right"></i>  more </a>
<br><br>
</div>

</div>

@endforeach



</div>
     
        </div>
</div>


   

     





     <!----- -->

     <div class="container-fluid ">
        <div class="container pad ">
             <div class="row text-center">
               <h2 class="col-12"> Customer reviews
   
                   <hr></h2>
                <p class="col-12">What did clients say about Bluzone?
   </p>
   @foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )
   
                    <div class="col-sm-4 col-12 relative wow fadeInRight" >
                        <img src="{{ asset($owner->img) }}" width="100%" >
                        <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                       <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                  </a>
                 </div>
                 @endforeach
                 
                                <div class="col-12"><a href="{{ route('clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  view all Customer reviews</a></div>
   
            </div></div></div>






         
       <!-----contact -->
   <div class="container-fluid contact">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> contact us now
               <hr></h2>
            <p class="col-12">contact to us 24 hours a day and talk to specialized engineers
</p>
                <div class="col-md-5    col-12" >
                    <div class="box">
                   <a href="tel:{{ $setting_v->contact_phone }}"> {{ $setting_v->contact_phone }}</a>
                       <div class="icon"><i class="fas fa-phone" ></i></div>  
                    </div>
                      <div class="box">
                   <a href="mailto: {{ $setting_v->contact_email }}"> Click to contact us</a>
                       <div class="icon"><i class="fas fa-envelope" ></i></div>  
                    </div>
                      <div class="box">
                   <a href="{{ $setting_v->fb_link }}/?ref=bookmarks"> Bluezone</a>
                       <div class="icon"><i class="fab fa-facebook" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->tw_link }}"> Bluezone</a>
                       <div class="icon"><i class="fab fa-twitter" ></i></div>  
                    </div>
                     <div class="box">
                   <a href="{{ $setting_v->insta_link }}/"> Bluezone</a>
                       <div class="icon"><i class="fab fa-instagram" ></i></div>  
                    </div>
                     <div class="box">
                           <div class="icon"><i class="fab fa-youtube" ></i></div>
                   <a href="{{ $setting_v->yt_link }}?view_as=subscriber"> Bluezone</a>
                       
                    </div>
                      <div class="box">
                           <div class="icon"><i class="fas fa-home" ></i></div> 
                   <a > {{ $setting_v->address_en }}</a>
                       
                    </div>
             </div>
             <div class="col-md-7 col-12" >
           <form method="post" action="{{ route('contact.user') }}" class=" row">
             @csrf
                 <div class="col-md-6">
                         <input name="name" required type="text" placeholder="name" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="company" required  type="text" placeholder="company" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="email" required type="text" placeholder=" E-mail" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="address" required type="text" placeholder=" Company Address" class="form-control">
                     </div>
                <div class="col-md-6">
                         <input name="phone" required type="text" placeholder="Phone / Please enter the country code" class="form-control">
                     </div>
               <div class="col-md-6">
                         <input name="wats" type="text" required placeholder="Whatsapp number / for easy communication" class="form-control">
                     </div>
                        <div class="col-md-12" >
                            <input name="title" required type="text" placeholder="project" class="form-control">
                    </div>
                     <div class="col-md-12">
                           <textarea name="content" required class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder="the message"></textarea>
                    </div>
                                      <div class="col-md-12">
                                          <button type="submit" value="" class="btn-w btn">send</button> 
               </div>
               </form>
             </div></div></div></div>
    <!----- -->

   
   
   

        <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
          <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection