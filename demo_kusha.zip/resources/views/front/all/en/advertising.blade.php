@extends('layouts.front2')

@section('title')
Advertising
@endsection

@section('content')
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
</div>
          <!----- -->
    <div class="container-fluid bg-light">
        <div class="container pad ">
             <div class="row text-center">
                <h3 class="col-12 main-color">Advertising</h3>
                <h2 class="col-12">
              All the services you need in one place, in safe hands
                    <hr></h2>
               <p class="col-12">Since 2011, we have been one of the largest software companies in Kwuite ... more than 1000 customers and thousands of solutions and services provided.
</p>
                 <div class="col-md-4 col-sm-6 col-12">
                 <a class="card pad-0" href="{{ route("galary") }}">
                     <img src="{{ asset('front/img/m.jpg') }}" class="card-img-top">
                      <div class="card-body">
                   <h5 class="card-title c-b" >gallery</h5>
                     </div>
                     </a>
                 </div>
                  
                
                   
                   
                 @foreach(\App\Models\Post::get() as $one)
                 <div class="col-md-4 col-sm-6 col-12">
               <a class="card pad-0" href="{{ route('advertising.user',$one->id) }}">
                   <img src="{{ asset($one->img) }}" class="card-img-top">
                    <div class="card-body">
                 <h5 class="card-title c-b" >{{ $one->title_en }}</h5>
                   </div>
                   </a>
               </div>

               @endforeach
            </div></div></div>
       <!----- -->
   
   
   

       <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
        <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>


@endsection