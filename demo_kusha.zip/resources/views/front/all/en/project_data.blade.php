@extends('layouts.front2')

@section('title')
    bluezone-project
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


    
     <!----- -->
     <div class="container-fluid bg-light">
        <div class="container pad ">
                 <div class="card  " >
                     <div class="row">
                      <div class=" col-md-6 col-12  ">
                          <br><br>
                          
                <h2>Project details</h2>
                          <hr class="float-left">
                          <div style="clear: both"></div>
                          
                          <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-sun"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>Site idea</h4>
                          <p> {!! htmlspecialchars_decode( $project->text1_en )  !!}
                               
                              </div></div>
                                    <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-database"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>To be executed</h4>
                          <p> {!! htmlspecialchars_decode( $project->text2_en )  !!}
                               
                              </div></div>
                           <div class="project-detials row" >
                          <div class="col-2 pad-0 ">
                        <a><i class="fas fa-clock"></i></a>
                          </div>
                           <div class="col-10">
                          <h4>Implementation and outcome</h4>
                          <p> {!! htmlspecialchars_decode( $project->text3_en )  !!}
                               
                              </div></div>
                   
                     </div>
                     <div class="col-md-6 col-12 pad-0">
                     <img src="{{ asset($project->img) }}" class="  w-100"  >
                         </div>
                      <ul  class=" col-12 text-center pad"  >
         

                    @if($project->link !="")
                    <li class="btn btn-light " ><a href="{{ $project->link }}" >Watch the site</a></li>
                                @endif
         
                                @if($project->ios !="")
                    <li class="btn btn-light"  ><a href="{{ $project->ios }}" > Download on app store <i class="fab fa-apple" style="font-size: 25px"></i></a></li>
                              @endif
         
                              @if($project->android !="")
                             <li class="btn btn-light" ><a href="{{ $project->android }}" > Download on google play  <i class="fab fa-android" style="font-size: 25px"></i></a></li>
                             @endif
         
                             <li class="btn btn-light" ><a href="{{ route('price') }}" >  Request for price</a></li>
                        
                 </ul>
                     </div>
                 </div>
                 </div>
            </div>
      
   <!----- -->
   <div class="container-fluid ">
    <div class="container pad ">
         <div class="row text-center">
           <h2 class="col-12"> Customer reviews

               <hr></h2>
            <p class="col-12">What did clients say about Bluzone?
</p>
@foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )

                <div class="col-sm-4 col-12 relative wow fadeInRight" >
                    <img src="{{ asset($owner->img) }}" width="100%" >
                    <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                   <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
              </a>
             </div>
             @endforeach
             
                            <div class="col-12"><a href="{{ route('clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  view all Customer reviews</a></div>

        </div></div></div>
  
     
     
      
   
        <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
          <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
               </a>
      <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
      <div class="modal-content"  style=" background: #04040480!important;border: none!important">
          <br>
       <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
           <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
          </button>
        <div class="modal-body">
            <br>
          <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
    <div class="carousel-inner">
      <div class="carousel-item active text-center">
     <iframe class=""  frameborder="0" src="https://www.youtube.com/embed/BS4TUd7FJSg?rel=0&amp;autoplay=1" 
             style="width: 80%;height: 80vh"></iframe>
        </div>
      <div class="carousel-item text-center">
       <iframe class=""  frameborder="0" src="https://www.youtube.com/embed/BS4TUd7FJSg?rel=0&amp;autoplay=1" 
             style="width: 80%;height: 80vh"></iframe>
      </div>
      <div class="carousel-item text-center">
        <iframe class=""  frameborder="0" src="https://www.youtube.com/embed/BS4TUd7FJSg?rel=0&amp;autoplay=1" 
             style="width: 80%;height: 80vh"></iframe>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
        </div>
       
      </div>
    </div>
  </div>

@endsection