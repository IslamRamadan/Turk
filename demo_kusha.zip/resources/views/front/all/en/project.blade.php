@extends('layouts.front2')

@section('title')
    bluezone-projects
@endsection

@section('content')
        
<div class="container-fluid  ">
    <img src="{{ asset('front/img/blog-bg.png') }}" width="100%" height="20%">
    </div>


    <!-----project -->
    <div class="container-fluid ">
        <div class="container pad project">
             <div class="row text-center">
                <h2 class="col-12">Our business and our projects
                    <hr></h2>
                 <p class="col-12">bluezone Company provides the best solutions and offers available for web design and application programming</p>
                    <div class="col-12" id="accordion">            
                <ul  class=" pad-0"  >
                    <li class="btn btn-light active" data-toggle="collapse" href="#collapse1" role="button" aria-expanded="false" aria-controls="collapse1" >  All projects</li>

           @foreach ($categories_v as $category )
           <li class="btn btn-light" data-toggle="collapse" href="#collapse{{$category->id }}" role="button" aria-expanded="false" aria-controls="collapse{{$category->id }}" >{{ $category->category_en }}</li>
           @endforeach
          
                    
               
                   </ul>
      <div id="collapse1" class="collapse row show" aria-labelledby="heading1" data-parent="#accordion">
   
       @foreach ($items_v  as $item )
       <div class="col-md-3 col-sm-6 col-12">
         <div class="img-project relative ">
             <img src="{{ asset($item->img) }}" >
             <a   href="{{ route("project.user",$item->id) }}" class="btn btn-light active abs" > {{ $item->name_en }}</a>
            </div>
     </div>
       @endforeach
      
          
      </div>
      @foreach ( $categories_v as $category )
   
      <div id="collapse{{$category->id }}" class="collapse row " aria-labelledby="heading2" data-parent="#accordion">
       @foreach (\App\Models\Item::where("activity",1)->where("category_id",$category->id )->get() as $item )
       <div class="col-md-3 col-sm-6 col-12">
                <div class="img-project relative ">
                    <img src="{{ asset($item->img) }}" >
                   <a target="" href="{{ route("project.user",$item->id) }}" class="btn btn-light active abs" > {{ $item->name_en }}</a>
                  </div>
            </div>
            @endforeach
   
              
        </div> 
      @endforeach
   
       
                     
                     
          
      </div>
      </div>    
        </div>

     











         
     <!-----contact -->
     <div class="container-fluid contact">
        <div class="container pad ">
             <div class="row text-center">
                <h2 class="col-12"> Request for price
                    <hr></h2>
                 <p class="col-12">Reach out to us 24 hours a day and talk to specialized engineers
  </p>
                 <div class=" col-md-8" >
               <form class=" row" method="post" action="{{ route('contact.user') }}">
              @csrf
                <input type="hidden" name="cart" value="cart">
                     <div class="col-md-6">
                             <input type="text" required name="name" placeholder="name" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="company"  placeholder="company" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="email"  placeholder=" e-mail" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="address"  placeholder=" Company Address" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <input type="text" required name="phone"  placeholder="Phone / Please enter the country code" class="form-control">
                         </div>
                   <div class="col-md-6">
                             <input type="text" required name="wats"  placeholder="Whatsapp number / for easy communication" class="form-control">
                         </div>
                   <div class="col-md-6">
                             <input type="text" required name="money"  placeholder="budget" class="form-control">
                         </div>
                    <div class="col-md-6">
                             <select class="form-control" required name="currency" >
                              <option class="form-control">KWD</option>  
                                 <option class="form-control">EGP</option>
                                 <option class="form-control">USD</option>
                     </select>
                         </div>
                            <div class="col-md-12">
                                <input required name="title"  type="text" placeholder="subject" class="form-control">
                        </div>
                         <div class="col-md-12">
                               <textarea required name="msg"  name="textarea-234" class="form-control" rows="7" class="wpcf7-form-control wpcf7-textarea form-control" aria-invalid="false" placeholder=" message"></textarea>
                        </div>
                                          <div class="col-md-12">
                                              <button type="submit" value="" class="btn-w btn">send</button> 
                   </div>
                   </form>
                 </div>
               <div class="col-md-4 d-md-block d-none">
                    <img src="{{ asset('front/img/mean.png') }}" class=" h-100 w-100 wow fadeInUp text-right">
                    </div>
            </div></div></div>
   

   
   

            <div class="container-fluid ">
                <div class="container pad ">
                     <div class="row text-center">
                       <h2 class="col-12"> Customer reviews
           
                           <hr></h2>
                        <p class="col-12">What did clients say about Bluzone?
           </p>
           @foreach (\App\Models\Owner::where("activity",1)->orderBy("tag","asc")->limit(3)->get() as $owner )
           
                            <div class="col-sm-4 col-12 relative wow fadeInRight" >
                                <img src="{{ asset($owner->img) }}" width="100%" >
                                <a href="" class="abs  bg-none" data-toggle="modal" data-target="#exampleModal" style="top: 40%;">
                               <span class="circle" id="circle"><i class="fas fa-caret-right" style="font-size: 35px;"></i></span>
                          </a>
                         </div>
                         @endforeach
                         
                                        <div class="col-12"><a href="{{ route('clients') }}" class="btn btn-light active"><i class="fas fa-arrow-right"></i>  view all Customer reviews</a></div>
           
                    </div></div></div>
              
   

                    <a href="https://wa.me/{{$setting_v->wats }}" class="whatsapp " style="z-index: 100" > 
                      <i class="fab fa-whatsapp" style="font-size: 40px;color:#fff"></i>
            </a>
   <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
 <div class="modal-dialog mr-0" role="document" style="max-width: 100%!important">
   <div class="modal-content"  style=" background: #04040480!important;border: none!important">
       <br>
    <button type="button" class="close text-right " data-dismiss="modal" aria-label="Close" style="background: #000;">
        <i class="fas fa-times-circle " style="font-size: 40px;background: #000;;color: #fff"></i>
       </button>
     <div class="modal-body">
         <br>
       <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
 <div class="carousel-inner">
 @php
    $i = 1 ; 
 @endphp
  @foreach ($owners_v as $owner )
    
 
   <div class="carousel-item @if($i==1) active  @endif    text-center">
  <iframe class=""  frameborder="0" src="{{   $owner->link }}?rel=0&amp;autoplay=1" 
          style="width: 80%;height: 80vh"></iframe>
     </div>
     @php
    $i++; 
 @endphp

     @endforeach
  
 </div>
 <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
   <span class="carousel-control-prev-icon" aria-hidden="true"></span>
   <span class="sr-only">Previous</span>
 </a>
 <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
   <span class="carousel-control-next-icon" aria-hidden="true"></span>
   <span class="sr-only">Next</span>
 </a>
</div>
     </div>
    
   </div>
 </div>
</div>

@endsection