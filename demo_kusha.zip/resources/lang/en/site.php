<?php

return [
    "app"=>"App",
    'project' => 'Blood Bank ',
    'dashboard' => 'home',
    'categories' => 'categories',
    'category' => 'category',
    'post' => 'post',
    'posts' => 'posts',
    'new' => ' new',
    'add_cat' => ' add category',
    'edit_cat' => 'edite category ',

    'bloodTypes' => ' blood Types',
    'bloodType' => ' blood Type',
    'add_blood' => ' add  blood Type',
    'edit_blood' => ' edit  blood Type',




    'logout' => 'تسجيل الخروج',

    'add' => 'add',
    'create' => 'create',
    'read' => 'read',
    'edit' => 'edit',
    'update' => 'update',
    'delete' => 'delete',
    'search' => 'search',
    'show' => 'show',
    'loading' => 'جاري التحميل',
    'print' => 'طبع',

    'confirm_delete' => 'confirm delete ',
    'yes' => 'yes',
    'no' => 'no',

    'login' => 'تسجيل الدخول',
    'remember_me' => 'تذكرني',
    'password' => 'كلمه المرور',
    'password_confirmation' => 'تاكيد كلمه المرور',

    'added_successfully' => 'تم اضافه البيانات بنجاح',
    'updated_successfully' => 'تم تعديل البيانات بنجاح',
    'deleted_successfully' => 'تم حذف البيانات بنجاح',

    'no_data_found' => 'للاسف لا يوجد اي سجلات',
    'no_records' => 'للاسف لا يوجد اي سجلات',

    'clients' => 'العملاء',
    'client_name' => 'اسم العميل',
    'phone' => 'التلفون',
    'address' => 'العنوان',

    'users' => 'المشرفين',
    'first_name' => 'الاسم الاول',
    'last_name' => 'الاسم الاخير',
    'email' => 'البريد الاكتروني',
    'image' => 'صوره',
    'action' => 'ادارة',

    'permissions' => 'الصلاحيات',






];
