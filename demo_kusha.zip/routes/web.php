<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['prefix' => LaravelLocalization::setLocale()], function()


{
    Route::get('/',  function(){
		
      if(app()->getLocale() == 'en'){
       echo cusha ;
      }
       $item = App\Models\Item::whereHas('sizes', function($q){
                $q->doesntHave("colors");
})->orDoesntHave("sizes")->get();
		
		 return get_response("0","error",$item);
    })->name("index");


    Route::get('/migrate', function() {
      $exitCode = Artisan::call('migrate');
      return '<h1>Cache facade value cleared</h1>';
  });

    










});
