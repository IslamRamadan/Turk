<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|//
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['prefix' => LaravelLocalization::setLocale()], function()
{

    Route::get('/clear', function() {
        \Illuminate\Support\Facades\Artisan::call('cache:clear');
         \Illuminate\Support\Facades\Artisan::call('config:cache');
           \Illuminate\Support\Facades\Artisan::call('route:clear');
           \Illuminate\Support\Facades\Artisan::call('view:clear');
    });
    
    Route::prefix('admin')->group(function() {
    Route::middleware(['auth',"auto-check-permission"])->group(function () {

       // Route::get('/dashboard', 'dashboardController@index')->name("my_admin");
       Route::get('/dashboard', 'dashboardController@index')->name("dashboard.index");
      Route::resource('/clients', 'clientController');
        Route::resource('/categories', 'categoryController');
        Route::resource('/subCategories', 'subCategoryController');
        Route::resource('/subSubCategories', 'subSubCategoryController');
        Route::resource('/brands', 'brandController');
        Route::resource('/sliders', 'sliderController');
        Route::resource('/items', 'itemController');
        Route::resource('/governs', 'governController');
		 Route::resource('/slashes', 'adController');
		 Route::resource('/countries', 'countryController');
        Route::get('/settings', 'settingController@index')->name('settings.index');
		
		Route::get('/store', 'storeController@index')->name('store.index');
	   Route::get('/items_storeg', 'itemController@items_storeg')->name('items.storeg');
	   Route::get('/items_no_active', 'itemController@items_no_active')->name('items.deactivate');
	   Route::get('/items_active', 'itemController@items_active')->name('items.activate');

        Route::get('/orders/get_cancel/{id}', 'orderController@get_cancel')->name('orders.get_cancel');
        Route::post('/orders/post_cancel/{id}', 'orderController@post_cancel')->name('orders.post_cancel');


        Route::post('/settings/update', 'settingController@update')->name('settings.update');

        Route::resource('/orders', 'orderController');
 //get order items
          Route::get('/order/items/{id}', 'orderItemController@index')->name('order.item');
        //get data about size and color for item
        Route::get('/items/sizes/{id}', 'itemController@size')->name('items.size');

        //add size for item 
        Route::post('/items/add/size/{id}', 'itemController@add_size')->name('items.add.size');
        //add color for item 
        Route::post('/items/add/color/{id}', 'itemController@add_color')->name('items.add.color');

         //update color for item 
         Route::post('/items/update/color/{id}', 'itemController@update_color')->name('items.update.color');

          //edit size for item 
          Route::get('/items/edit/size/{id}', 'itemController@edit_size')->name('items.edit.size');
           //update size for item 
           Route::put('/items/update/size/{id}', 'itemController@update_size')->name('items.update.size');

            //update size for item 
            Route::delete('/items/destroy/size/{id}', 'itemController@destroy_size')->name('items.destroy.size');

        // get product images 

        Route::get('/galaries/{id}', 'galaryController@index')->name("galaries.index");
       // Route::get('/galaries/create/{id}', 'galaryController@create')->name("galaries.create");
        Route::post('/galaries/store/{id}', 'galaryController@store')->name("galaries.store");


        Route::delete('/galaries/destroy/{id}', 'galaryController@destroy')->name("galaries.destroy");

////////////////////////////////////////////////////////////////////////////////////
     




        Route::resource('/roles', 'roleController');
        Route::resource('/users', 'userController');
       

        
        Route::get('/profile', 'profileController@index')->name('profile.index');

        Route::post('/profile/email', 'profileController@email')->name('profile.email');
        Route::post('/profile/password', 'profileController@password')->name('profile.password');
        Route::post('/profile/username', 'profileController@username')->name('profile.username');

    });
    Auth::routes();
    Route::get('logout', 'Auth\logoutController@logout')->name('user_logout');
});

});
