<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class OrderItem  extends Model {

	protected $table = 'orderItems';
	public $timestamps = false;
    protected $guarded = [];

	protected $appends = [   "img_full_path","name"] ;


	public function order (){
		return $this->belongsTo(Order::class, 'order_id');
	}

	public function  getImgFullPathAttribute()
    {
        return asset($this->img) ;
	}
	
	public function  getNameAttribute()
    {
        return Item::find($this->item_id)->name ;
    }

}
