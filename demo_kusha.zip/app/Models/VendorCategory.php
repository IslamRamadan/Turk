<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class VendorCategory  extends Model {

	protected $table = 'vendorCategories';
	public $timestamps = false;
    protected $guarded = [];
	 public function apps ()
    {
        return $this->hasMany('App\Models\Vendor');
    }



	

	

}
