<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Slashe extends Model 
{

    protected $table = 'slashes';
    public $timestamps = true;
    protected $fillable = array('activity', 'num', 'img',"link");
protected $appends = [   "img_full_path"] ;


    public function  getImgFullPathAttribute()
    {
        return asset($this->img) ;
    }
}