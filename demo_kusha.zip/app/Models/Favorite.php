<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Favorite extends Model 
{

    protected $table = 'favorites';
    public $timestamps = false;
	    protected $fillable = array('id', 'item_id', 'user_id',"api_token");


}