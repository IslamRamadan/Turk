<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Order  extends Model {

	protected $table = 'orders';
	public $timestamps = true;
    protected $guarded = [];

	protected $appends = ["items" ,"date"] ;




 

   

   
    public function  getItemsAttribute()
    {
		return  OrderItem::where("order_id",$this->id)->get();
	  }

	  public function getDateAttribute(){
		$newtime = strtotime( $this->created_at);
		return date('d-m-Y H:i:s', 	$newtime);
	  }

}
