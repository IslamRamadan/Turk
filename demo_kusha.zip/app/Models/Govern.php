<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Govern extends Model {

	protected $table = 'governs';
	public $timestamps = false;
    protected $guarded = [];



}
