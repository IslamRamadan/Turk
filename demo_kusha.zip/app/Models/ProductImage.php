<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ProductImage extends Model 
{

    protected $table = 'productImages';
    public $timestamps = false;
    protected $fillable = array('item_id', 'img',"size_id","num","activity");
    protected $appends = [   "img_full_path" ] ;

    
    public function  getImgFullPathAttribute()
    {
        return asset($this->img) ;
    }

}