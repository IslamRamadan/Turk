<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Client extends Model 
{

    protected $table = 'clients';
    public $timestamps = true;
    protected $fillable = array('name', 'activity', 'api_token', 'password', 'phone',"country","pine_code","phone_code","balance");

}