<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubSubCategory extends Model 
{

    protected $table = 'subSubCategories';
    public $timestamps = false;
    protected $fillable = array('name',"name_en","category_id", 'img', 'subCategory_id', 'activity', 'num');

}