<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SubCategory  extends Model
{
   // protected $hidden = [

        //"created_at",
        //"updated_at"

 //  ];
 
 
    protected $table = 'subCategories';
	public $timestamps = false;
    protected $guarded = [];
    protected $appends = [   "sub" ,"img_full_path"] ;


    public function  getImgFullPathAttribute()
    {
        return asset($this->img) ;
    }

    public function subsubCategories ()
    {
        return $this->hasMany('App\Models\SubSubCategory');
    }


    public function items ()
    {
        return $this->hasMany('App\Models\Item');
    }

    

  
  


   

    public function   getSubAttribute()
    {
        
   return   SubSubCategory::where("subCategory_id",$this->id)->where("activity",1)->orderBy("num","asc")->get();

    
    }

}
