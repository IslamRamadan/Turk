<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Cart extends Model {

	protected $table = 'carts';
	public $timestamps = true;
    protected $guarded = [];
    protected $appends = [   "item" ] ;
	
	public function   getItemAttribute()
    {
        
   return   Item::find($this->item_id);

    
    }


}
