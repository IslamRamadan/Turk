<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Over extends Model 
{

    protected $table = 'overs';
    public $timestamps = true;
    protected $fillable = array('activity', 'num', 'img', 'text');

}