<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientItem extends Model 
{

    protected $table = 'client_item';
    public $timestamps = true;
    protected $fillable = array('client_id', 'item_id');

}