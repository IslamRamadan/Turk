<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ItemTag extends Model 
{

    protected $table = 'item_tag';
    public $timestamps = true;
    protected $fillable = array('item_id', 'tag_id',"type");

}