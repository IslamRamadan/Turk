<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ClientToken extends Model 
{

    protected $table = 'client_token';
    public $timestamps = true;

}