<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
class Vendor  extends Model {

	protected $table = 'vendors';
	public $timestamps = true;
    protected $guarded = [];
	 protected $appends = [  "img_full_path"] ;


    public function  getImgFullPathAttribute()
    {
        return asset($this->img) ;
    }



	

	

}
