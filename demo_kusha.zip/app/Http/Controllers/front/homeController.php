<?php

namespace App\Http\Controllers\front;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\ContactMesseg;
use  App\Models\Cart;
use  App\Models\Item;
use  App\Models\Post;


use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class homeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     * 
     * 
     * 
     */
    public function advertising($id)
    {
      $record = Post::findOrFail($id);

      if(app()->getLocale() == 'en'){
        return view("front.all.en.advertising_one",compact("record"));
    
      }
  return view("front.all.advertising_one",compact("record"));

    }


    public function project($id)
    {

  $project = Item::findOrFail($id);
  if(app()->getLocale() == 'en'){
    return view("front.all.en.project_data",compact("project"));

  }
  return view("front.all.project_data",compact("project"));

    }




    public function contact(Request $request)
    {

        $messeges = [
            '*.required'=>" اكمل البيانات",

          

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'max:200',
            '*' => 'required',
            'email' => 'max:100',
            'phone' => 'max:100',
            'wats' => 'max:100',
            'title' => 'max:300',
            'msg' => 'max:1000',            
            'content' => 'max:1000',  
            'money' => 'max:200',  
            'msg' => 'max:1000',        
            'address' => 'max:300',   
            'company' => 'max:300',            
         
    
          
          

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
     if($request->cart=="cart"){
        $request->offsetUnset('cart');
        $create= Cart::create($request->all());


     }else{
        $create= ContactMesseg::create($request->all());


     }

        if($create){
            Alert::success('Success', 'تم الارسال بنجاح');
        }else{
            Alert::error('Error', '  حاول مرة اخري');
        }
       
              return back();
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    }

}
