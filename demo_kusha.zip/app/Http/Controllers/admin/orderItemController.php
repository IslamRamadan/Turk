<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Order;
use  App\Models\OrderItem;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class orderItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$id)
    {

      // flash('Welcome Aboard!');
       $order = Order::find($id);
      $orders = OrderItem::where("order_id",$id)->paginate(10);
        return view("/dashboard/orderItems/index",["orders"=>  $orders ,"order"=>$order]);
    }

   
}
