<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Country;
use  App\Models\Govern;

use  App\Models\Item;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class CountryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

      // flash('Welcome Aboard!');

      $countries =Country::orderBy("num","desc")->get();
		//dd($countries);

        return view("/dashboard/countries/index",["data"=>  $countries ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/dashboard/countries/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messeges = [

            'name.required'=>"اسم الدولة مطلوب",
            'name.unique'=>"اسم الدولة موجود من قبل",
            'name_en.required'=>"اسم الدولة بالانجليزية مطلوب",
            'name_en.unique'=>"اسم الدولة بالانجليزية موجود من قبل",
             "qut.Numeric"=>"لابد لقيمة العملة ان تكون رقمية",


           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|unique:countries,name',
            'name_en' => 'required|unique:countries,name_en',
            "qut"=> "required|Numeric",
            "code"=>"required",
            "currency"=>"required",


        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        $Country= Country::create($request->all());
        if ($Country){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('countries.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category = Country::findOrFail($id);
        return view('/dashboard/countries/edit',["category"=>$category ]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

         $messeges = [

            'name.required'=>"اسم الدولة مطلوب",
            'name.unique'=>"اسم الدولة موجود من قبل",
            'name_en.required'=>"اسم الدولة بالانجليزية مطلوب",
            'name_en.unique'=>"اسم الدولة بالانجليزية موجود من قبل",
            "qut.Numeric"=>"لابد لقيمة العملة ان تكون رقمية",



           ];


       //  dd( $Country);
        $validator =  Validator::make($request->all(), [

            'name' => 'required|unique:countries,name,' .$id,
            'name_en' => 'required|unique:countries,name_en,' .$id,
             "qut"=> "required|Numeric",
            "code"=>"required",
            "currency"=>"required",

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
        $Country= Country::findOrFail($id);
        $Country= $Country->update($request->all());
        if ($Country){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success ', 'Success Message');
         }

            return redirect()->route('countries.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $Country= Country::findOrFail($id);
  

      $items = Govern::Where("country_id",$id)->count();

      if($items > 0){
        Alert::error('Error', 'يجب حذف  المدن التابعة لهذه الدولة اولا');
        return back();
      }
      $Country->delete();
     // session()->flash('success', __('site.deleted_successfully'));



     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('countries.index');

    }
}
