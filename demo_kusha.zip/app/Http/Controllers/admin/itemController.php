<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\ProductImage;
use  App\Models\Item;
use  App\Models\Size;
use  App\Models\Color;

use  App\Models\SubCategory;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class ItemController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
	
	
	 public function items_storeg(Request $request)
    {
		
		  $items1 =Item::where("type",1)->whereHas('sizes', function($q){
                $q->doesntHave("colors");
})->get();
		 //->orDoesntHave("sizes")
		 $items2 = Item::where("type",2)->where("qut",0)->orWhere("qut",null)->get();
		 
		 $result = $items1->merge($items2);
		// return get_response("0","error",$result);
		         return view("/dashboard/items/qut",["categories"=>  $result,]);

	 }
	
	 public function items_no_active(Request $request)
    {
		//dd("jjjcjj");
		  $items1 =Item::where("type",1)->whereHas('sizes', function($q){
                $q->doesntHave("colors");
})->orDoesntHave("sizes")->get();
		 
		 $items2 = Item::where("type",2)->where("qut",0)->orWhere("qut",null)->get();
		 
		 $result = $items1->merge($items2);
		// return get_response("0","error",$result);
		 foreach($result as $one){
		 $done=$one->update(["activity"=>0]);
		 }
		  if($done)
			 {
			  Alert::success('success', "تمت العملية بنجاح");
              return back();
			 }
			 else{
				  Alert::error('error', "حاول مرة اخري");
            return back();
			 }

	 }
	
	
	 public function items_active(Request $request)
    {
		//dd("jjjcjj");
		  $items1 =Item::where("type",1)->whereHas('sizes', function($q){
                $q->doesntHave("colors");
})->orDoesntHave("sizes")->get();
		 
		 $items2 = Item::where("type",2)->where("qut",0)->orWhere("qut",null)->get();
		 
		 $result = $items1->merge($items2);
		// return get_response("0","error",$result);
		 foreach($result as $one){
		 $done=$one->update(["activity"=>1]);
		 }
		  if($done)
			 {
			  Alert::success('success', "تمت العملية بنجاح");
              return back();
			 }
			 else{
				  Alert::error('error', "حاول مرة اخري");
            return back();
			 }

	 }
    public function index(Request $request)
    {

      // flash('Welcome Aboard!');

      $categories = Item::where(function ($q) use ($request) {
        if ($request->search) {
            $q->where('name', 'LIKE', '%' . $request->search . '%');
        }
        if ($request->category_id) {
            $q->where('category_id',$request->category_id );
        }

        if ($request->subCategory_id) {
            $q->where('subCategory_id',$request->subCategory_id );
        }

        if ($request->subSubCategory_id) {
            $q->where('subSubCategory_id',$request->subSubCategory_id );
        }
        if ($request->brand_id) {
            $q->where('brand_id',$request->brand_id );
        }
        if ($request->slider_id) {
            $q->where('slider_id',$request->slider_id );
        }
    })->orderBy("id","desc")->paginate(10);

        return view("/dashboard/items/index",["categories"=>  $categories,]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/dashboard/items/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $messeges = [

           
            'photo.required'=>"صورة القسم مطلوبة",
            'photo.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'photo.max'=>" الحد الاقصي للصورة 4 ميجا ",
            

           ];


        $validator =  Validator::make($request->all(), [
            "description_en"=>"required",

			'name_en' => 'required',
            'name' => 'required',
            "subCategory_id"=>"required",
            "subSubCategory_id"=>"required",
            "category_id"=>"required",
            "price"=>"required",
            "over_price"=>"required",
            "description"=>"required",
            'photo' => 'required|mimes:jpg,jpeg,png|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        $img =  $request->photo ;
        //add new name for img
        $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();
  
        //move img to folder
       $move = $img->move(public_path("upload/items"), $new_name_img);
      // dd(public_path("upload"));
      // $move2= move_uploaded_file( $_FILES["logo"]["tmp_name"],public_path("upload")."/".$new_name_img) ;
      // dd($move2);
  
         $new = "upload/items/".$new_name_img ;
         $request->merge(['img' => $new]);

        $category= Item::create($request->except(['photo']));
        if ($category){

            ProductImage::create([
             "item_id"=>$category->id,
             "img"=>$request->img,

            ]);

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success ', 'Success Message');
         }

            return redirect()->route('items.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category=Item::findOrFail($id);
        return view('/dashboard/items/edit',["category"=>$category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $messeges = [

           
            'photo.required'=>"صورة القسم مطلوبة",
            'photo.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'photo.max'=>" الحد الاقصي للصورة 4 ميجا ",
            

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required',
			 "description_en"=>"required",

			'name_en' => 'required',
            "subCategory_id"=>"required",
            "subSubCategory_id"=>"required",
            "category_id"=>"required",
            "price"=>"required",
            "over_price"=>"required",
            "description"=>"required",
            'photo' => 'mimes:jpg,jpeg,png|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        if($request->photo){
            $img =  $request->photo ;
            //add new name for img
            $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();
      
            //move img to folder
           $move = $img->move(public_path("upload/items"), $new_name_img);
          // dd(public_path("upload"));
          // $move2= move_uploaded_file( $_FILES["logo"]["tmp_name"],public_path("upload")."/".$new_name_img) ;
          // dd($move2);
      
             $new = "upload/items/".$new_name_img ;
             $request->merge(['img' => $new]);
        }
        $category= Item::findOrFail($id);
        $category= $category->update($request->except(['photo']));
        if ($category){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success ', 'Success Message');
         }

            return redirect()->route('items.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $category= Item::findOrFail($id);
  
      if(file_exists(public_path( $category->img))){
        unlink(public_path($category->img));
                  }
     
      $category->delete();


      $size = Size::where("item_id",$id)->get();
      if($size){
          foreach ($size as $one){
              $one->delete();
          }
      }

      $color = Color::where("item_id",$id)->get();
      if($color){
          foreach ($color as $one){
          
              $one->delete();
          }
      }

      $img = ProductImage::where("item_id",$id)->get();
      if($img){
          foreach ($img as $one){
            if(file_exists(public_path( $one->img))){
                unlink(public_path($one->img));
                          }
              $one->delete();
          }
      }
     // session()->flash('success', __('site.deleted_successfully'));



     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('items.index');

    }



    public function size( $id)
    {
     
        $item= Item::findOrFail($id);
        $sizes = Size::where("item_id",$id)->with("colors")->orderBy("id","desc")->get();
        return view('/dashboard/items/size',["sizes"=>$sizes,"id" =>$id]);

    }


    public function add_size( $id,Request $request)
    {
        $item= Item::findOrFail($id);

        $messeges = [

           
            'name.required'=>"يجب ادخال اسم المقاس",
            'name.max'=>"الحد الاقصي للمقاس 7 احرف او ارقام",
           

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|max:7',
          
        ], $messeges);

        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        $record = Size::create([
           "name"=>$request->name ,
           "item_id"=>$id
        ]);


        if($record){
            Alert::success('success',"تمت العملية بنجاح");
            return redirect()->route('items.size',$id);


        }else{
            Alert::error('error',"حاول مرة اخري");
            return back();

        }

    }








    public function add_color( $id,Request $request)
    {
        $item= Item::findOrFail($id);
        $size= Size::findOrFail($request->hidden);

        $messeges = [

           
            'name.required'=>"يجب ادخال اسم اللون",
            'qut.required'=>"يجب ادخال  الكمية",
            'name.max'=>"الحد الاقصي للون 10 احرف او ارقام",
           

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|max:10',
			 'name_en' => 'required|max:10',
            "qut"=>"required"
          
        ], $messeges);

        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        for($i=0;$i<$request->qut;$i++){

            $record = Color::create([
                "name"=>$request->name ,
				  "name_en"=>$request->name_en ,
                "item_id"=>$id,
                "size_id"=>$request->hidden,
                "size"=>$size->name
             ]);

        }

       


        if($record){
            Alert::success('success',"تمت العملية بنجاح");
            return redirect()->route('items.size',$id);


        }else{
            Alert::error('error',"حاول مرة اخري");
            return back();

        }

    }






    public function update_color( $id,Request $request)
    {
        $item= Item::findOrFail($id);
        $color= Color::findOrFail($request->hidden_color);
        $size= Size::findOrFail($request->hidden_size);

        $messeges = [

           
            'name.required'=>"يجب ادخال اسم اللون",
            'qut.required'=>"يجب ادخال  الكمية",
            'name.max'=>"الحد الاقصي للون 10 احرف او ارقام",
           

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|max:10',
			'name_en' => 'required|max:10',
            "qut"=>"required"
          
        ], $messeges);

        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }


        $all = Color::where("item_id",$id)->where("size_id",$request->hidden_size)->where("name",$color->name)->get();
      //  dd($all);

        foreach($all as $one){
          $one->delete();

        }

        if($request->delete){

            Alert::success('success',"تمت العملية بنجاح");
            return redirect()->route('items.size',$id);

        }else{

        for($i=0;$i<$request->qut;$i++){

            $record = Color::create([
                "name"=>$request->name ,
                "item_id"=>$id,
                "size_id"=>$request->hidden_size,
                "size"=>$size->name,
				 "name_en"=>$request->name_en ,
             ]);

        }

       


        if($record){
            Alert::success('success',"تمت العملية بنجاح");
            return redirect()->route('items.size',$id);


        }else{
            Alert::error('error',"حاول مرة اخري");
            return back();

        }


    }

    }



    public function edit_size( $id)
    {
    $size =Size::findOrFail($id);

        return view('/dashboard/items/edit_size',["size"=>$size]);


    }



    public function update_size( $id,Request $request)
    {
    $size =Size::findOrFail($id);

    $messeges = [

           
        'name.required'=>"يجب ادخال اسم المقاس",
        'name.max'=>"الحد الاقصي للمقاس 7 احرف او ارقام",
       

       ];


    $validator =  Validator::make($request->all(), [

        'name' => 'required|max:7',
      
    ], $messeges);

    if ($validator->fails()) {
        Alert::error('error', $validator->errors()->first());
        return back();
    }

    $record = $size->update([
       "name"=>$request->name ,
    ]);


    if($record){
          
        $row = Color::where("size_id",$id)->get();

        foreach($row as $one){

            $one->update([
                "size"=>$request->name ,
             ]);
         
        }

        Alert::success('success',"تمت العملية بنجاح");
        return redirect()->route('items.size',$size->item_id);


    }else{
        Alert::error('error',"حاول مرة اخري");
        return back();

    }


    }





    public function destroy_size( $id,Request $request)
    {

    $size =Size::findOrFail($id);
    
    $colors = Color::where("size_id",$id)->get();

    foreach ($colors as $one) {
        
       $one->delete();

    }


    $del= $size->delete();

    if($del){
        Alert::success('success',"تمت العملية بنجاح");
        return redirect()->route('items.size',$size->item_id);


    }else{
        Alert::error('error',"حاول مرة اخري");
        return back();

    }


}
}
