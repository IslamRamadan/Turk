<?php
namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Color;
use  App\Models\Order;
use  App\Models\Item;
use  App\User;
use  App\Models\Client;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class StoreController extends Controller
{

public function index (Request $request){

//get all price of products 
	
	// 1- product has size and color 
	$products_has_color =  Color::has("item")->has("size")->with("item")->get()->sum('item.over_price');
	
	
	
	//2-product has only qut
	$products_has_only_qut = Item::where("type",2)->select(\DB::raw('(over_price * qut) as      total'),"name")->get()->sum('total');
	
	
	
	
	//get all price of orders
	$all_orders_price =  Order::where("status","!=",4)
		->where(function ($query) use($request){

        if ($request->input('from') && $request->input('to'))

        {
            if($request->input('to') >= $request->input('from')){
            $query->whereBetween('created_at', [$request->input('from'), $request->input('to')]);
            }
            if($request->input('to') <= $request->input('from')){
                $query->whereBetween('created_at', [$request->input('to'), $request->input('from')]);
                }
        }
		})
		->get()->sum("price");
	
	//get paid order 
	$paid_order =  Order::where("status","!=",4)->where(function ($query) use($request){

        if ($request->input('from') && $request->input('to'))

        {
            if($request->input('to') >= $request->input('from')){
            $query->whereBetween('created_at', [$request->input('from'), $request->input('to')]);
            }
            if($request->input('to') <= $request->input('from')){
                $query->whereBetween('created_at', [$request->input('to'), $request->input('from')]);
                }
        }
		})
		->where("type","!=","cach")->orWhere("status",3)
		->get()->sum("price");
	
	
	
	
	//get non paid order 
	$not_paid_order =  Order::where("type","cach")->where("status","!=",3)->where("status","!=",4)
		->where(function ($query) use($request){

        if ($request->input('from') && $request->input('to'))

        {
            if($request->input('to') >= $request->input('from')){
            $query->whereBetween('created_at', [$request->input('from'), $request->input('to')]);
            }
            if($request->input('to') <= $request->input('from')){
                $query->whereBetween('created_at', [$request->input('to'), $request->input('from')]);
                }
        }
		})
		->get()->sum("price");
	
	
	
	//get all balance of clients
		$all_balance_users =  Client::select("balance")->get()->sum("balance");
 
	
	//order canced
	$all_orders_cancled =  Order::where("status",4)
		->where(function ($query) use($request){

        if ($request->input('from') && $request->input('to'))

        {
            if($request->input('to') >= $request->input('from')){
            $query->whereBetween('created_at', [$request->input('from'), $request->input('to')]);
            }
            if($request->input('to') <= $request->input('from')){
                $query->whereBetween('created_at', [$request->input('to'), $request->input('from')]);
                }
        }
		})
		->get()->sum("price");
	
	        return view("/dashboard/store/index",
			["has_color"=>  $products_has_color,
			"has_qut"=>  $products_has_only_qut,
			"all_orders_price"=>  $all_orders_price,
			"not_paid_order"=>  $not_paid_order,
			 "paid_order"=>  $paid_order,
			"cancel_order"=>  $all_orders_cancled,
			"balance"=>  $all_balance_users,]);

	
 //return get_response("1", "loaded...  ", $all_orders_price);
}

}

?>