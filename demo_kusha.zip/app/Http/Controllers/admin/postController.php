<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Post;
use  App\Models\Category;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class postController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $posts = post::where(function ($query) use($request){
            if ($request->input('keyword'))

                {
                    $query->where(function ($query) use($request){
                        $query->where('title','like','%'.$request->keyword.'%');
                       


                    });
                }
               
        })->paginate(15);
      // flash('Welcome Aboard!');



        return view("/dashboard/posts/index",["posts"=>  $posts ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/dashboard/posts/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messeges = [

            'img.required'=>"صورة القسم مطلوبة",
            'img.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'img.max'=>" الحد الاقصي للصورة 4 ميجا ",
            'title.required'=>"عنوان القسم مطلوب",
            'content.required'=>"محتوي القسم مطلوب",
            'title_en.required'=>"عنوان القسم بالانجليزية مطلوب",
            'content_en.required'=>"محتوي القسم بالانجليزية مطلوب",


           ];


        $validator =  Validator::make($request->all(), [
            'title' => 'required',
            'title_en' => 'required',
            'content' => 'required',
            'content_en' => 'required',
            'img' => 'required|mimes:jpg,jpeg,png|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

       $img = $request->img;
       $title= $request->title;
       $content = $request->content;
       $title_en= $request->title_en;
       $content_en = $request->content_en;

       //add new name for img
       $new_name_img = time().".".$img->getClientOriginalExtension();

       //move img to folder
       $img->move(public_path("upload/advertising"), $new_name_img);

        $post= Post::create([
       "img"=>  "upload/advertising/".$new_name_img ,
       "title"=>  $title ,
       "content"=>  $content ,
       "title_en"=>  $title_en ,
       "content_en"=>  $content_en ,
        ]);
        if ($post){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('posts.index');

        }else{

            session()->flash('error', "error");
            if(session()->has("error")){
               Alert::success('error Title', 'error Message');
            }

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $post= post::with("category")->findOrFail($id);

        return view('/dashboard/posts/edit',["post"=>$post]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messeges = [


            'img.required'=>"صورة القسم مطلوبة",
            'img.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png او gif",
            'img.max'=>" الحد الاقصي للصورة 4 ميجا ",
            'title.required'=>"عنوان القسم مطلوب",
            'content.required'=>"محتوي القسم مطلوب",
            'title_en.required'=>"عنوان القسم بالانجليزية مطلوب",
            'content_en.required'=>"محتوي القسم بالانجليزية مطلوب",


           ];


        $validator =  Validator::make($request->all(), [
            'title' => 'required',
            'title_en' => 'required',
            'content' => 'required',
            'content_en' => 'required',
            'img' => 'mimes:jpg,jpeg,png|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
if($_FILES["img"]["name"] != ""){
       $img = $request->img;
       $title= $request->title;
       $content = $request->content;
       $title_en= $request->title_en;
       $content_en = $request->content_en;


       //add new name for img
       $new_name_img = time().".".$img->getClientOriginalExtension();

       //move img to folder
       $img->move(public_path("upload/advertising"), $new_name_img);
       $post=Post::findOrFail($id);
        $post=  $post->update([
       "img"=>  "upload/advertising/".$new_name_img ,
       "title"=>  $title ,
       "content"=>  $content ,
       "title_en"=>  $title_en ,
       "content_en"=>  $content_en ,
        ]);

}else{


    $title= $request->title;
    $content = $request->content;
    $title_en= $request->title_en;
    $content_en = $request->content_en;

    $post=Post::findOrFail($id);
    $post=  $post->update([
    "title"=>  $title ,
    "content"=>  $content ,
    "title_en"=>  $title_en ,
    "content_en"=>  $content_en ,
     ]);


}
        if ($post){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('posts.index');

        }else{

            session()->flash('error', "error");
            if(session()->has("error")){
               Alert::success('error Title', 'error Message');
            }

        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $post= Post::findOrFail($id);
      if(file_exists(public_path( $post->img))){
        unlink(public_path($post->img));
    };
      $post->delete();
     // session()->flash('success', __('site.deleted_successfully'));
     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('posts.index');

    }
}
