<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Post;
use  App\Models\ProductImage;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;

class galaryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,$id)
    {
        $posts = ProductImage::where("item_id",$id)->get();
      // flash('Welcome Aboard!');



        return view("/dashboard/galary/index",["posts"=>  $posts,"id"=>$id ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
   // public function create($id)
    //{
      //  return view('/dashboard/galary/create',compact("id"));
    //}

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,$id)
    {

        if (!$request->hasfile('img')){

            Alert::success('error ', 'لم تقم بتحميل اي صورة');
            return back();
        }

    $imgs = $request->img ;

    if(count($imgs) >10 ){

        Alert::success('error ', 'الحد الاقصي للتحميل في المرة الواحدة 10 صور');
        return back();

    }


    $messeges = [

        'img.required'=>" الصورة مطلوبة",
        'img.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png ",
        'img.max'=>" الحد الاقصي للصورة 4 ميجا ",
        

       ];


    $validator =  Validator::make($request->all(), [
      
        'img.*' => 'mimes:jpg,jpeg,png|max:4100',
        "img"=>"required"

    ], $messeges);



    if ($validator->fails()) {
        Alert::error('error', $validator->errors()->first());
        return back();
    }

    

$error = 0 ;
    foreach($imgs as $img){

       
     

       //add new name for img
       $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();

       //move img to folder
       $img->move(public_path("upload/advertising"), $new_name_img);

        $post= ProductImage::create([
       "img"=>  "upload/advertising/".$new_name_img ,
       "item_id"=>$id
      
        ]);

        if(!$post){
            $error++ ;
        }
       



    }

    if ($error == 0){

        session()->flash('success', "success");
     if(session()->has("success")){
        Alert::success('Success Title', 'Success Message');
     }

        return redirect()->route('galaries.index',$id);

    }else{

        session()->flash('error', "بعض الصور او جميعها لم يتم تحميلها");
        if(session()->has("error")){
           Alert::success('error Title', 'error Message');
        }

    }


     
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    
    public function destroy( $id)
    {

      $post= ProductImage::findOrFail($id);
      if(file_exists(public_path( $post->img))){
        unlink(public_path($post->img));
                  }
      $post->delete();
     // session()->flash('success', __('site.deleted_successfully'));
     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('galaries.index',$post->item_id);

    }
}
