<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Category;
use  App\Models\SubSubCategory;
use  App\Models\SubCategory;

use  App\Models\Item;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class SubSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

      // flash('Welcome Aboard!');

      $categories = SubSubCategory::where(function ($q) use ($request) {
        if ($request->search) {
            $q->where('name', 'LIKE', '%' . $request->search . '%');
        }
        if ($request->category_id) {
            $q->where('category_id',$request->category_id );
        }
        if ($request->subCategory_id) {
            $q->where('subCategory_id',$request->subCategory_id );
        }
    })->paginate(10);

        return view("/dashboard/subSubCategories/index",["categories"=>  $categories ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/dashboard/subSubCategories/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        $messeges = [

            'subCategory_id.required'=>" القسم الفرعي مطلوب",
            'category_id.required'=>" القسم  مطلوب",
            'name.required'=>"اسم  التصنيف   مطلوب",

            'name_en.required'=>"اسم  التصنيف  بالانجليزية مطلوب",
            'photo.required'=>"صورة القسم مطلوبة",
            'photo.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'photo.max'=>" الحد الاقصي للصورة 4 ميجا ",
            

           ];


        $validator =  Validator::make($request->all(), [
            "category_id"=>"required",


            'subCategory_id' => 'required',
            'name_en' => 'required',
            'name' => 'required',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }



        $category= SubSubCategory::create($request->all());
        if ($category){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('subSubCategories.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $category=SubSubCategory::findOrFail($id);
        return view('/dashboard/subSubCategories/edit',["category"=>$category]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $messeges = [

            'name.required'=>"اسم القسم الفرعي مطلوب",
            'category_id.required'=>" القسم  مطلوب",
            'name.unique'=>"اسم القسم الفرعي موجود من قبل",
            'name_en.required'=>"اسم القسم الفرعي  بالانجليزية مطلوب",
            'photo.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'photo.max'=>" الحد الاقصي للصورة 4 ميجا ",
            

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required',
            'name_en' => 'required',
            "category_id"=>"required",
            'photo' => 'mimes:jpg,jpeg,png|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        if($request->photo){
            $img =  $request->photo ;
            //add new name for img
            $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();
      
            //move img to folder
           $move = $img->move(public_path("upload/subSubCategories"), $new_name_img);
          // dd(public_path("upload"));
          // $move2= move_uploaded_file( $_FILES["logo"]["tmp_name"],public_path("upload")."/".$new_name_img) ;
          // dd($move2);
      
             $new = "upload/subSubCategories/".$new_name_img ;
             $request->merge(['img' => $new]);
        }
        $category= SubSubCategory::findOrFail($id);
        $category= $category->update($request->except(['photo']));
        if ($category){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success ', 'Success Message');
         }

            return redirect()->route('subSubCategories.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $category= SubSubCategory::findOrFail($id);
  

      $items = Item::Where("SubSubCategory_id",$id)->count();

      if($items > 0){
        Alert::error('Error', 'يجب حذف المنتجات التابعة لهذا  التصنيف  اولا');
        return back();
      }
      $category->delete();
     // session()->flash('success', __('site.deleted_successfully'));



     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('subSubCategories.index');

    }
}
