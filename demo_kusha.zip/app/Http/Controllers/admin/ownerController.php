<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Owner;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class OwnerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

      // flash('Welcome Aboard!');

      $owners = Owner::where(function ($q) use ($request) {
        if ($request->search) {
            $q->where('name', 'LIKE', '%' . $request->search . '%');
        }
    })->orderBy("tag","asc")->paginate(10);

        return view("/dashboard/owners/index",["owners"=>  $owners ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/dashboard/owners/create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messeges = [
            'img.required'=>"  الصورة مطلوبة",

            'name.required'=>"اسم العميل مطلوب",
            'name.unique'=>"اسم العميل موجود من قبل",
            'link.required'=>"الرابط  مطلوب",
            'link.unique'=>" الرابط موجود من قبل",
            'img.required'=>"صورة المقال مطلوبة",
            'img.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png  ",
            'img.max'=>" الحد الاقصي للصورة 4 ميجا ",


           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|unique:owners',
            "link"=>'required',
            'img' => 'required|mimes:jpg,jpeg,png,gif|max:4100',

        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
        $img = $request->img;
        $link= $request->link;
        $tag = $request->tag;
        $activity= $request->activity;
        $name = $request->name;
 
        //add new name for img
        $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();
 
        //move img to folder
        $img->move(public_path("upload/owners"), $new_name_img);
 
         $owner= Owner::create([
        "img"=>  "upload/owners/".$new_name_img ,
        "link"=>  $link ,
        "tag"=>  $tag ,
        "name"=>  $name ,
 
        "activity"=>  $activity ,
 
         ]);
        if ($owner){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('owners.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $owner= Owner::findOrFail($id);
        return view('/dashboard/owners/edit',["owner"=>$owner]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messeges = [

            'img.required'=>"  الصورة مطلوبة",

            'name.required'=>"اسم العميل مطلوب",
            'name.unique'=>"اسم العميل موجود من قبل",
            'link.required'=>"الرابط  مطلوب",
            'link.unique'=>" الرابط موجود من قبل",
            'img.mimes'=>" يجب ان تكون الصورة jpg او jpeg او png ",
            'img.max'=>" الحد الاقصي للصورة 4 ميجا ",



           ];


        $validator =  Validator::make($request->all(), [
            'name' => 'required|unique:owners,name,'.$id,
            "link"=>'required',
            'img' => 'mimes:jpg,jpeg,png|max:4100',


        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
if($_FILES["img"]["name"] != ""){
    $img = $request->img;
    $link= $request->link;
    $tag = $request->tag;
    $activity= $request->activity;
    $name = $request->name;

       //add new name for img
       $new_name_img = time().uniqid().".".$img->getClientOriginalExtension();

       //move img to folder
       $img->move(public_path("upload/owners"), $new_name_img);
       $owner=Owner::findOrFail($id);
            $owner=  $owner->update([
                "img"=>  "upload/owners/".$new_name_img ,
                "link"=>  $link ,
                "tag"=>  $tag ,
                "name"=>  $name ,
         
                "activity"=>  $activity ,
         
        ]);

}else{


    $link= $request->link;
    $tag = $request->tag;
    $activity= $request->activity;
    $name = $request->name;


    $owner=Owner::findOrFail($id);
    $owner=  $owner->update([
        "link"=>  $link ,
        "tag"=>  $tag ,
        "name"=>  $name ,
 
        "activity"=>  $activity ,
 
]);


}
        if ($owner){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('owners.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {
   
      $Owner= Owner::findOrFail($id);
      if(file_exists(public_path( $Owner->img))){
        unlink(public_path($Owner->img));
    };
    
      $Owner->delete();
     // session()->flash('success', __('site.deleted_successfully'));
     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('owners.index');

    }
}
