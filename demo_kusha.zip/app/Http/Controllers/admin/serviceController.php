<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Service;
use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class serviceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        //dd(icons()[0]["c"] );
      // flash('Welcome Aboard!');

      $services = Service::where(function ($q) use ($request) {
        if ($request->search) {
            $q->where('name', 'LIKE', '%' . $request->search . '%');
        }
    })->orderBy("tag","asc")->paginate(10);

        return view("/dashboard/services/index",["services"=>  $services ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $icons = icons();

        return view('/dashboard/services/create',[ "icons"=>  $icons]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $messeges = [

            'name.max'=>"الحد الاقصي لاسم الخدمة 25 حرف",
            'name.min'=>"الحد الادني لاسم الخدمة 3 احرف",
            'text.max'=>"الحد الاقصي لوصف الخدمة 300 حرف",

            'text_en.max'=>"الحد الاقصي لوصف الخدمة بالانجليزية 300 حرف",
            'text.min'=>"الحد الادني لوصف الخدمة 100 حرف",

            'text_en.min'=>"الحد الادني لوصف الخدمة بالانجليزية 100 حرف",
            'name_en.max'=>"الحد الاقصي لترجمة اسم  الخدمة 25 حرف",
            'name_en.min'=>"الحد الادني لترجمة اسم الخدمة 3 احرف",
            'name.required'=>"اسم الخدمة مطلوب",
            'name.unique'=>"اسم الخدمة موجود من قبل",
            'icon.required'=>" الايقونة مطلوبة",


           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|unique:services,name|max:25|min:3',
            "icon"=>"required",
            "name_en"=>'required|unique:services,name_en|max:25|min:3',
            "text"=>'required|max:300|min:100',
            "text_en"=>'required|max:300|min:100',


        ], $messeges);



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }

        $Service= Service::create($request->all());
        if ($Service){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('services.index');

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $icons = icons();

        $service= Service::findOrFail($id);
        return view('/dashboard/services/edit',["service"=>$service,"icons"=>  $icons]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $messeges = [

            'name.max'=>"الحد الاقصي لاسم الخدمة 25 حرف",
            'name.min'=>"الحد الادني لاسم الخدمة 3 احرف",
            'text.max'=>"الحد الاقصي لوصف الخدمة 300 حرف",

            'text_en.max'=>"الحد الاقصي لوصف الخدمة بالانجليزية 300 حرف",
            'text.min'=>"الحد الادني لوصف الخدمة 100 حرف",
            
            'text_en.min'=>"الحد الادني لوصف الخدمة بالانجليزية 100 حرف",
            'name_en.max'=>"الحد الاقصي لترجمة اسم  الخدمة 25 حرف",
            'name_en.min'=>"الحد الادني لترجمة اسم الخدمة 3 احرف",
            'name.required'=>"اسم الخدمة مطلوب",
            'name.unique'=>"اسم الخدمة موجود من قبل",
            'icon.required'=>" الايقونة مطلوبة",

           ];


        $validator =  Validator::make($request->all(), [

            'name' => 'required|max:25|min:3||unique:services,name,' .$id,
            'name' => 'required|max:25|min:3||unique:services,name_en,' .$id,
            "icon"=>"required",
            "text"=>'required|max:300|min:100',
            "text_en"=>'required|max:300|min:100',


        ], $messeges);



      



        if ($validator->fails()) {
            Alert::error('error', $validator->errors()->first());
            return back();
        }
        $Service= Service::findOrFail($id);
        $Service= $Service->update($request->all());
        if ($Service){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success Title', 'Success Message');
         }

            return redirect()->route('services.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $Service= Service::findOrFail($id);

    
      $Service->delete();
     // session()->flash('success', __('site.deleted_successfully'));
     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('services.index');

    }
}
