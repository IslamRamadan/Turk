<?php

namespace App\Http\Controllers\admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use  App\Models\Order;
use  App\Models\OrderItem;
use  App\Models\Client;

use Illuminate\Support\Facades\Validator;
use RealRashid\SweetAlert\Facades\Alert;


class orderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

      // flash('Welcome Aboard!');

      $orders = Order::where(function ($q) use ($request) {
        if ($request->phone) {
            $q->where("phone", $request->phone );
        }
        if ($request->code) {
            $q->where("id", $request->code );
        }
        if ($request->status) {
            $q->where("status", $request->status );
        }
        if ($request->govern) {
            $q->where("govern", $request->govern );
        }
		   if ($request->user_id) {
            $q->where("user_id", $request->user_id );
        }
    })->orderBy("id","desc")->paginate(10);

        return view("/dashboard/orders/index",["orders"=>  $orders ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function post_cancel(Request $request,$id)
    {
        if($request->type==""){
			Alert::error('error', "1خطأ غير متوقع");
            return back();
		}
		 
		
		if($request->type==0){
			
			$order=Order::findOrFail($id);
			$order->update(["status"=>4]);
		     Alert::success('Success ', 'Success Message');
            return redirect()->route('orders.index');
		}
		
		
		if($request->type==1){
			
             $order=Order::findOrFail($id);

							if($order->user_id==0 ||$order->user_id==""){
							   Alert::error('error', "3خطأ غير متوقع");
								return back();
							}
			 $user = Client::findOrFail($order->user_id);	
			$user->update(["balance"=>$order->price]);

			$order->update(["status"=>4]);
		     Alert::success('Success ', 'Success Message');
            return redirect()->route('orders.index');
		}
		
		if($request->type==2){
			
					if($request->user_id==0 ||$request->user_id==""){
                       Alert::error('error', "2خطأ غير متوقع");
                        return back();
					}
			 $order=Order::findOrFail($id);
			 $user = Client::findOrFail($request->user_id);
			$user->update(["balance"=>$order->price]);
			$order->update(["status"=>4]);
		     Alert::success('Success ', 'Success Message');
            return redirect()->route('orders.index');
		}
		
		
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
   
    public function get_cancel($id)
    {
        $Order= Order::findOrFail($id);
        return view('/dashboard/orders/show',["Order"=>$Order]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $Order= Order::findOrFail($id);
        return view('/dashboard/orders/edit',["Order"=>$Order]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

       
        $Order= Order::findOrFail($id);
        $Order= $Order->update($request->all());
        if ($Order){

            session()->flash('success', "success");
         if(session()->has("success")){
            Alert::success('Success ', 'Success Message');
         }

            return redirect()->route('orders.index');

        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy( $id)
    {

      $Order= Order::findOrFail($id);
  
     $items = OrderItem::where("order_id",$id)->get();

     foreach ($items as $one){
         $one->delete();
     }
     
      
      $Order->delete();
     // session()->flash('success', __('site.deleted_successfully'));



     session()->flash('success', "success");
     if(session()->has("success")){
      Alert::success('Success Title', 'Success Message');
     }
      return redirect()->route('orders.index');

    }
}
