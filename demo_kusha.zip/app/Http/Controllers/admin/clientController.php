<?php

namespace App\Http\Controllers\admin;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use RealRashid\SweetAlert\Facades\Alert;

class clientController extends Controller
{




    public function index(Request $request)

    {

 

        $users = Client::where(function ($query) use($request){
            if ($request->input('keyword'))
            {
                $query->where(function ($query) use($request){
                    $query->where('name','like','%'.$request->keyword.'%');
                    $query->orWhere('phone','like','%'.$request->keyword.'%');


                });
            }

           
        })->paginate(20);

        return view('dashboard/clients/index',compact('users'));
    }

    public function create(User $model)
    {
        return view('/dashboard/users/create',compact('model'));
    }

    /**
     * @param Request $request
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(Request $request)
    {
//        dd();
        $this->validate($request, [
            'name' => 'required',
            'password' => 'required|confirmed',
            'email' => 'email|required|unique:users,email',
            'roles_list'  => 'required'
        ]);
        $request->merge(['password' => bcrypt($request->password)]);
        $user = User::create($request->except('roles_list'));
        $user->roles()->attach($request->input('roles_list'));

        Alert::success('success','تــم اضــافة المستخدم بنجــاح');
        return back();
    }

    public function show($id)
    {
    }

    public function edit($id)
    {
        $user = Client::findOrFail($id);
        return view('dashboard/clients.edit',compact('user'));
    }

    /**
     * @param Request $request
     * @param $id
     * @return \Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     * @throws \Illuminate\Validation\ValidationException
     */
    public function update(Request $request , $id)
    {
        $this->validate($request, [
            'activity' => 'required',
            
        ]);
        $user = Client::findOrFail($id);

       $update = $user->update($request->all());
      


        if($update ){
        Alert::success('success','تــم تحديث المستخدم بنجــاح');
        return back();
        }else{
            Alert::error('error','خطأ غير متوقع');
            return back();
        }
    }

    public function destroy($id)
    {
        $record = Client::findOrFail($id);

        if (!$record) {
            Alert::error('error','خطأ غير متوقع');
            return back();
        }

        $record->delete();
        Alert::success('success','تمت العملية بنجاح');
        return back();
    }
}
