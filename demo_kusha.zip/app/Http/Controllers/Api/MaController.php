<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Addon;

use App\Models\Client;
use App\Models\Ma_cat;
use App\Models\Ma_item;



use Illuminate\Support\Facades\Validator;

use App\Offer as AppOffer;
use DB;

use Illuminate\Http\Request;

class MaController extends Controller
{
    
   
    


    public function cats()
    {
        $cats = Ma_cat::with("meals")->where("status",1)->get();
        return get_response("1", "جاري التحميل", $cats );
    }

    
    
     public function items(Request $request)
    {
        $items = Ma_item::where("status",1)->get();
        return get_response("1", "جاري التحميل", $items );
    }

   




    


}
