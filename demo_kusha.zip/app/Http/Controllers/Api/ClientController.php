<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\Client;
use  App\Models\Token;

use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use App\Mail\reset_password;

class ClientController extends Controller

{

  
    public  function register(Request $request)
    {
       $messeges = [
           
            'password.required'=>"حقل كلمة المرور مطلوب",
            'password.min'=>"كلمة المرور لا تقبل اقل من 6 علامات",
            'password.confirmed'=>"كلمة المرور غير متطابقة",


            'phone.required'=>"حقل رقم الهاتف فارغ ",
            'phone.required'=>"حقل الدولة  فارغ ",
            'phone.unique'=>"رقم الهاتف موجود من قبل",
            
              'name.required'=>"حقل الاسم  فارغ ",
            'name.unique'=>" الاسم موجود من قبل",
             'name.max'=>" الاسم  لا يتجاوز 30 حرف ",
            'name.min'=>" الاسم موجود  لا يقل عن 4 احرف",

           ];

        $validator =  Validator::make($request->all(), [
           
            'password' => 'required|min:6',

            'phone' => 'required|unique:clients,phone',
             'name' => 'required|min:4|max:30',
             "country"=>"required",
           
        ], $messeges);


        if ($validator->fails()) {
            return get_response("0", $validator->errors()->first(), $validator->errors());
        }

        $request->merge(["password" => bcrypt($request->password)]);
        $client = Client::create([
            "phone"=>$request->phone,
            "phone_code"=>$request->code,
              "password"=>$request->password,
                "name"=>$request->name,
                 "country"=>$request->country,
                 "api_token"=>$request->token,
                 "pine_code"=>rand("111111", "999999")
            ]);
            if($request->token==""){
                $client->api_token =  Str::random(60);
                $client->save();
            }
        

       

        if( $client){

            
            $text = " كود التفعيل    " . $client->pine_code;

           $send =  sms("KUSHA",$client->phone_code.$client->phone,$text);

if($send){
    return get_response("1", "تمت الاضافة بنجاح", [

        "api_token" => $client->api_token,

        "client" => $client,


    ]);
}else{

    $client->delete();
    return get_response("0", "1حاول مرة اخري","");
}
           

        }else{
            $client->delete();

            return get_response("0", "2حاول مرة اخري","");

        }
        
        
    }



    /////////////////////////////////////////////////////////////////////////////////////////

    public function activation (Request $request){
        $messeges = [
       "code.required"=>"الكود فارغ",
       "code.token"=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه او تحدث مع الدعم الفني",

    ];


 $validator =  Validator::make($request->all(), [

     'code' => 'required',
     "token"=>"required"
 ],$messeges);



 if ($validator->fails()) {
     return get_response("0", "بيانات المستخدم غير صحيحة", $validator->errors()->first());
 }



 $client =  Client::where("pine_code", $request->code)->where("api_token", $request->token)->first();
 $client_count =  Client::where("pine_code", $request->code)->where("api_token", $request->token)->count();
 if($client_count  == 1){
     $client->update ([
         "activity"=>1,
         "pine_code"=>""
     ]);

     return get_response("1", "تمت العملية بنجاح", [

        "api_token" => $client->api_token,

        "client" => $client,


    ]); }else{
    return get_response("0", "الكود غير صالح", "الكود غير صالح");


 }

    }



    public  function login(Request $request)
    {
        $messeges = [

            'password.required'=>"حقل كلمة المرور مطلوب",
            'password.min'=>"كلمة المرور لا تقبل اقل من 6 علامات",
            'phone.required'=>"حقل رقم التليفون فارغ ",

           ];


        $validator =  Validator::make($request->all(), [

            'password' => 'required',
            'phone' => 'required',
        ], $messeges);



        if ($validator->fails()) {
            return get_response("0", "بيانات المستخدم غير صحيحة", $validator->errors());
        }







        $client = Client::where("phone", $request->phone)->where("activity",1)->first();

//dd($client);

        

         

        if ($client) {
            $token = $client->api_token;
        $password = $client->password;

                if (Hash::check($request->password, $password)) {
                return get_response("1", "تم مصادقة البيانات بنجاح", [

                    "api_token" => $token,

                    "client" => $client,
                ]);

                } else {

                return get_response("0", "بيانات المستخدم غير صحيحة", "    رقم التليفون هذا غير مسجل");
                }

               } else {

               return get_response("0", "بيانات المستخدم غير صحيحة", " كلمة المرور غير صحيحة");
        }
    }




    ///////////////////////////////////////////////////////////////////////////////////




    public  function resetPassword(Request $request)
    {
        $messeges = [
            "phone.required"=>"رقم الهاتفود فارغ",
            "token.required"=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه او تحدث مع الدعم الفني",
     
         ];
     
     
      $validator =  Validator::make($request->all(), [
     
          'phone' => 'required',
         
      ],$messeges);



        if ($validator->fails()) {
            return get_response("0", "بيانات المستخدم غير صحيحة", $validator->errors());
        }



        $record =  Client::where("phone", $request->phone)->first();

        $count =  Client::where("phone", $request->phone)->count();

        if ($count !=1){

            return get_response("0", "بيانات المستخدم غير صحيحة", $validator->errors());

        }

        

        if ($record) {
          

           $client = $record->update([
               "pine_code"=>rand("111111", "999999")

           ]);


            if ($client) {
                $client = Client::find($record->id);

                $text = " كود  تغيير كلمة المرور   " . $client->pine_code;

                $send =  sms("KUSHA",$client->phone_code.$client->phone,$text);
     
     if($send){
         return get_response("1", "ادخل كلمة سر جديدة", [
     
             "api_token" => $client->api_token,
     
             "client" => $client,
     
     
         ]);
     }else{
     
       
         return get_response("0", "1حاول مرة اخري","");
     }


              



               
            } else {
                return get_response("0", "حاول مرة اخري", "حاول مرة اخري");
            }
        } else {

            return get_response("0", "بيانات المستخدم غير صحيحة", "    رقم التليفون هذا غير مسجل");
        }
    }




    /////////////////////////////////////////////////////////////////////////////////////////



    public  function changPassword(Request $request)
    {
        $messeges = [

            'password.required'=>"حقل كلمة المرور مطلوب",
            'token.required'=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه",
            'password.min'=>"كلمة المرور لا تقبل اقل من 6 علامات",
           

            'code.required'=>"كود التحقق مطلوب",

           ];


        $validator =  Validator::make($request->all(), [

            'code' => 'required',
            'token' => 'required',
            'password' => 'required|min:6',

        ], $messeges);



        if ($validator->fails()) {
            return get_response("0", $validator->errors()->first(), $validator->errors());
        }



        $record =  Client::where("pine_code", $request->code)->where("api_token", $request->token)->first();

        if ($record) {
           
            $record->password =  bcrypt($request->password);
            $record->pine_code = null;
            $record->save();


            $token = $record->api_token;

            $client = Client::find($record->id);

            return get_response("1", "تمت العملية بنجاح", [
     
                "api_token" => $client->api_token,
        
                "client" => $client,
        
        
            ]);



          
        } else {

            return get_response("0", "كود التفعيل غير صالح", "    كود التفعيل  غير صحيح");
        }
    }


    ////////////////////////////////////////////////////////////




    
    /////////////////////////////////////////////////////////////////////////////////////////



    public  function change_phone(Request $request)
    {
        $messeges = [

            'token.required'=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه",
           

            'code.required'=>"كود التحقق مطلوب",

           ];


        $validator =  Validator::make($request->all(), [

            'code' => 'required',
            'token' => 'required',

        ], $messeges);



        if ($validator->fails()) {
            return get_response("0", $validator->errors()->first(), $validator->errors());
        }



        $record =  Client::where("pine_code", $request->code)->where("api_token",$request->token)->first();

        if ($record) {
           
            $record->phone = $request->phone;
            $record->phone_code = $request->phone_code;
            $record->country = $request->country;
            $record->pine_code = null;
            $record->save();


            $token = $record->api_token;

            $client = Client::find($record->id);

            return get_response("1", "تمت العملية بنجاح", [
     
                "api_token" => $client->api_token,
        
                "client" => $client,
        
        
            ]);



          
        } else {

            return get_response("0", "كود التفعيل غير صالح", "    كود التفعيل  غير صحيح");
        }
    }


    ////////////////////////////////////////////////////////////




    public  function edit_phone(Request $request)
    {
        $messeges = [
            "phone.required"=>"رقم الهاتفود فارغ",
            "code.required"=>"حاول مرة اخري",
            "country.required"=>"اختر الدولة",
            "token.required"=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه او تحدث مع الدعم الفني",
     
         ];
     
     
      $validator =  Validator::make($request->all(), [
     
          'phone' => 'required',
          'country' => 'required',
          'code' => 'required',
          "token"=>"required"
      ],$messeges);



        if ($validator->fails()) {
            return get_response("0", "اكمل البيانات او حاول مرة اخري ", $validator->errors());
        }



        $record =  Client::where("api_token",$request->token)->first();

        $count =  Client::where("api_token",$request->token)->count();
        if ($count !=1){

            return get_response("0", "بيانات المستخدم غير صحيحة", $validator->errors());

        }

        

        if ($record) {
          

           $client = $record->update([
               "pine_code"=>rand("111111", "999999")

           ]);


            if ($client) {
                $client = Client::find($record->id);

                $text = " كود  تغيير  رقم الهاتف   " . $client->pine_code;  

                $send =  sms("KUSHA",$request->code.$request->phone,$text);
     
     if($send){
         return get_response("1", "ادخل كلمة سر جديدة", [
     
             "api_token" => $client->api_token,
     
             "client" => $client,
     
     
         ]);
     }else{
     
       
         return get_response("0", "1حاول مرة اخري","");
     }


              



               
            } else {
                return get_response("0", "حاول مرة اخري", "حاول مرة اخري");
            }
        } else {

            return get_response("0", "بيانات المستخدم غير صحيحة", "    رقم التليفون هذا غير مسجل");
        }
    }



    //////////////////////////////////////////////////////





    public  function edit_pass(Request $request)
    {
        $messeges = [

            'new.required'=>"حقل كلمة المرور الجديدة مطلوب",
            'old.required'=>"حقل كلمة المرور القديمة مطلوب",
            'token.required'=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه",
            'password.min'=>"كلمة المرور لا تقبل اقل من 6 علامات",
           


           ];


        $validator =  Validator::make($request->all(), [

            'old' => 'required',
            'token' => 'required',
            'new' => 'required|min:6',

        ], $messeges);



        if ($validator->fails()) {
            return get_response("0", $validator->errors()->first(), $validator->errors());
        }



        $client = Client::where("api_token", $request->token)->first();

//dd($client);

        

         

        if ($client) {
            $token = $client->api_token;
        $password = $client->password;

                if (Hash::check($request->old, $password)) {

                    $request->merge(["new" => bcrypt($request->new)]);

                    $client->update([
                        "password"=>$request->new
                    ]);



                return get_response("1", "تم مصادقة البيانات بنجاح", [

                    "api_token" => $token,

                    "client" => $client,
                ]);

                } else {

                return get_response("0", "بيانات المستخدم غير صحيحة", "    رقم التليفون هذا غير مسجل");
                }

               } else {

               return get_response("0", "بيانات المستخدم غير صحيحة", " كلمة المرور غير صحيحة");
        }
    }


    

/////////////////////////////////////////////////////////


public  function edit_user(Request $request)
{
    $messeges = [

        'name.required'=>"حقل الاسم  مطلوب",
        'token.required'=>"خطأ غير متوقع اغلق التطبيق ثم اعد فتحه",
       
       

   

       ];


    $validator =  Validator::make($request->all(), [

        'name' => 'required',
        'token' => 'required',
       

    ], $messeges);



    if ($validator->fails()) {
        return get_response("0", $validator->errors()->first(), $validator->errors());
    }



    $record =  Client::where("api_token",$request->token)->first();

    if ($record) {
       
        $record->name =  $request->name ;
      
        $record->save();


        $token = $record->api_token;

        $client = Client::find($record->id);

        return get_response("1", "تمت العملية بنجاح", [
 
            "api_token" => $client->api_token,
    
            "client" => $client,
    
    
        ]);



      
    } else {

        return get_response("0", "حاول مرة اخري " ,"حاول مرة اخري");
}


}

    /////////////////////////////////////////////////////////////////////////////////////////




   



    /////////////////////////////////////////////////////////////////////////////////////////





    /////////////////////////////////////////////////////////////////////////////////////////



    public function registerToken(Request $request)
    {

        $rules = [
            'token' => 'required',

        ];


        $validator = validator()->make($request->all(), $rules);
        if ($validator->fails()) {
            return get_response(0, $validator->errors()->first(), $validator->errors());
        }


        Token::where("token",$request->token)->delete();
        $request->Client()->tokens()->create($request->all());
        return get_response(1, 'تمت الاضافة بنجاح',"");



    }




    /////////////////////////////////////////////////////////////////////////////////////////



    public function removeToken(Request $request)
    {
        $rules = [
            'token' => 'required',

        ];



        $validator = validator()->make($request->all(), $rules);
        if ($validator->fails()) {
            return get_response(0, $validator->errors()->first(), $validator->errors());
        }



        Token::where("token",$request->token)->delete();

        return get_response(1, 'تم الحذف بنجاح',"");



    }
}
