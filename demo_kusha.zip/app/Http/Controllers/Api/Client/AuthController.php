<?php

namespace App\Http\Controllers\Api\Client;

use App\Models\Client;
use App\Models\Token;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Input;
use Illuminate\Validation\Rule;
use Illuminate\Support\Str;
use App\Mail\reset_password;


class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'name'      => 'required',
            'phone'     => 'required',
            'city_id' => 'required',
            'email'     => 'required|unique:clients,email',
            'password'  => 'required|confirmed',
          //  'profile_image'  => 'required|image|mimes:png,jpeg',
        ]);

        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        $userToken =Str::random(60);
        $request->merge(array('api_token' => $userToken));
        $request->merge(array('password' => bcrypt($request->password)));
        $user = Client::create($request->all());
        if ($request->hasFile('profile_image')) {

            $path = public_path();
            $destinationPath = $path . '/uploads/clients/'; // upload path
            $photo = $request->file('profile_image');
            $extension = $photo->getClientOriginalExtension(); // getting image extension
            $name = time() . '' . rand(11111, 99999) . '.' . $extension; // renameing image
            $photo->move($destinationPath, $name); // uploading file to given path
            $user->profile_image = 'uploads/clients/' . $name;
        }

        $user->save();
        if ($user) {
            $data = [
                'api_token' => $userToken,
                'client'      => $user->load('city')
            ];

            return get_response(1, 'تم التسجيل بنجاح', $data);
        } else {
            return get_response(0, 'حدث خطأ ، حاول مرة أخرى');
        }
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function profile(Request $request)
    {
        //dd($request->user()->id);
        $validation = validator()->make($request->all(), [
            'password'      => 'confirmed',
            Rule::unique('users')->ignore($request->user()->id),
            'profile_image' => 'image|mimes:png,jpeg',
        ]);
        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        if ($request->has('name')) {
            $request->user()->update($request->only('name'));
        }
        if ($request->has('email')) {
            $request->user()->update($request->only('email'));
        }
        if ($request->has('password')) {
            $request->merge(array('password' => bcrypt($request->password)));
            $request->user()->update($request->only('password'));
        }

        if ($request->has('phone')) {
            $request->user()->update($request->only('phone'));
        }

        if ($request->has('city_id')) {
            $request->user()->update($request->only('city_id'));
        }

        if ($request->has('address')) {
            $request->user()->update($request->only('address'));
        }

        $loginUser = $request->user();
        $loginUser->update($request->except('profile_image'));
        if ($request->hasFile('profile_image')) {
                if (file_exists($loginUser->profile_image))
                    unlink($loginUser->profile_image);

                $path = public_path();
                $destinationPath = $path . '/uploads/clients/'; // upload path
                $photo = $request->file('profile_image');
                $extension = $photo->getClientOriginalExtension(); // getting image extension
                $name = time() . '' . rand(11111, 99999) . '.' . $extension; // renameing image
                $photo->move($destinationPath, $name); // uploading file to given path
                $loginUser->profile_image = 'uploads/clients/' . $name;
            }
            $loginUser->save();

        $data = [
            'client' => $request->user()->load('city')
        ];
        return get_response(1, 'تم تحديث البيانات', $data);
    }


    /**
     * @param Request $request
     * @return mixed
     */
    public function login(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'phone'    => 'required',
            'password' => 'required'
        ]);
        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        $user = Client::where('phone', $request->input('phone'))->first();
       // dd( $user);
        if ($user) {
            if (Hash::check($request->password, $user->password)) {
               // dd(Hash::check($request->password, $user->password));

                // check if not activated
                $data = [
                    'api_token' => $user->api_token,
                    'client'      => $user->load('city'),
                ];
                return get_response(1, 'تم تسجيل الدخول', $data);
            } else {
                return get_response(0, 'بيانات الدخول غير صحيحة',"error");
            }
        } else {
            return get_response(0, 'بيانات الدخول غير صحيحة',"error");
        }
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function reset(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'email' => 'required'
        ]);

        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        $user = Client::where('email', $request->email)->first();
        if ($user) {
            $code = rand(111111, 999999);
            $update = $user->update(['pin_code' => $code]);
            if ($update) {

                  Mail::to($user->email)

                    ->bcc("moha228830@gmail.com")
                    ->send(new reset_password($code));


                return get_response(1, 'برجاء فحص بريدك الالكتروني',"success");
            } else {
                return get_response(0, 'حدث خطأ ، حاول مرة أخرى',"error");
            }
        } else {
            return get_response(0, 'لا يوجد أي حساب مرتبط بهذا البريد الالكتروني',"error");
        }
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function password(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'pin_code'     => 'required',
            'password' => 'confirmed|required'
        ]);

        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        $user = Client::where('pin_code', $request->pin_code)->where('pin_code', '!=', "")->first();
        //dd($request->password);
        if ($user) {
            $update = $user->update(['password' => bcrypt($request->password), 'pin_code' => null]);

            if ($update) {
                 $data = [
                    'api_token' => $user->api_token,
                    'client'      => $user->load('city'),
                ];
                return get_response(1, 'تم تغيير كلمة المرور بنجاح',$data);
            } else {
                return get_response(0, 'حدث خطأ ، حاول مرة أخرى',"error");
            }
        } else {
            return get_response(0, 'هذا الكود غير صالح',"error");
        }
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function registerToken(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'type'  => 'required|in:android,ios',
            'token' => 'required',
        ]);

        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        Token::where('token', $request->token)->delete();

        $request->user()->tokens()->create($request->all());
        return get_response(1, 'تم التسجيل بنجاح',"success");
    }

    /**
     * @param Request $request
     * @return mixed
     */
    public function removeToken(Request $request)
    {
        $validation = validator()->make($request->all(), [
            'token' => 'required',
        ]);

        if ($validation->fails()) {
            $data = $validation->errors();
            return get_response(0, $validation->errors()->first(), $data);
        }

        Token::where('token', $request->token)->delete();
        return get_response(1, 'تم الحذف بنجاح بنجاح');
    }
}
