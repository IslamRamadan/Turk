<?php

namespace App\Http\Controllers\Api;
use Illuminate\Support\Facades\Mail;
use App\Mail\reset_password;

use App\Http\Controllers\Controller;

use App\Models\Vendor;

use App\Models\VendorCategory;
use Illuminate\Support\Facades\Validator;

use DB;

use Illuminate\Http\Request;

class shopsController extends Controller
	{
 public function apps(Request $request)
    {
   $cats = VendorCategory::whereHas('apps')->with("apps")->get();
   
   if($cats){
  
	    return get_response("1","success updated",$cats);

   }else{
     $add = VendorCategory::create($request->all());
	    return get_response("1","success added",$cats);
   }
	    return get_response("0","error",[]);

    }	
	
	
	
	
	
	
	
}

?>