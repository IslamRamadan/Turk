<?php

namespace App\Http\Controllers\Api;
use Illuminate\Support\Facades\Mail;
use App\Mail\reset_password;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Slider;
use App\Models\Slashe;
use App\Models\Country;
use App\Models\Setting;
use App\Models\Vendor;

use App\Models\Over;
use App\Models\Brand;
use App\Models\Item;
use App\Models\Color;
use App\Models\Cart;
use App\Models\Govern;

use App\Models\SubCategory;
use App\Models\SubSubCategory;
use App\Models\Order;
use App\Models\Notification;

use App\Models\OrderItem;

use App\Models\Favorite;






///////////////////////////////
use App\Models\City;
use App\Models\Client;

use App\Models\Meal;
use Illuminate\Support\Facades\Validator;
use App\Models\Offer;
use App\Models\PaymentType;
use App\Models\Restaurant;
use App\Models\Section;
 
use App\Models\Transfer;

use App\Offer as AppOffer;
use DB;

use Illuminate\Http\Request;

class MainController extends Controller
	{
 public function if_login(Request $request)
    {
   $user = Client::where("api_token",$request->api_token)->first();
   
   if($user){
   $user->update($request->all());
	    return get_response("1","success updated",$user);

   }else{
     $add = Client::create($request->all());
	    return get_response("1","success added",$user);
   }
	    return get_response("0","error",[]);

    }	
	

	
	 public function add_favorite(Request $request){
	 if($request->id=="" || $request->token==""  || $request->user_id==""){
		         return get_response("0","error",[]);
	 }
		 
	$records = Favorite::create([
	"user_id"=>$request->user_id,
	"api_token"=>$request->token,
	"id"=>$request->id,
	])	;
		
        if($records){
        return get_response("1", "loaded...  ", $records);

		}else{
		   return get_response("0","error",[]);

		}	
	 }
	
	public function delete_favorite(Request $request){
	 if($request->id=="" || $request->token=="" || $request->user_id==""){
		         return get_response("0","error",[]);
	 }
		
		$del = Favorite::where("item_id",$request->id)->first()->delete();
			if($del){
        return get_response("1", "loaded...  ", "");

		}else{
		   return get_response("0","error",[]);

		}	
		
		
	 }
	
	public function get_favorite(Request $request){
	 if($request->token==""){
		         return get_response("0","error",[]);
	 }
		
		$del = Favorite::where("token",$request->token)->first()->delete();
			if($del){
        return get_response("1", "loaded...  ", "");

		}else{
		   return get_response("0","error",[]);

		}	
		
	 }


  public function cart_num(Request $request)
    {
    (string) $record = Cart::where("token",$request->token)->count();
     return get_response("1", "loaded...  ",  "$record");

    }

    // web ajax get subcategory

    public function ajax_subcats(Request $request)
    {

        $category_id = $request->category_id ;
        $records = SubCategory::where("category_id", $category_id)->get();


        return get_response("1", "loaded...  ", $records);
    }


    // web ajax get subsubcategory

    public function ajax_subcats2(Request $request)
    {

        $category_id = $request->category_id ;
        $records = SubSubCategory::where("subCategory_id", $category_id)->get();


        return get_response("1", "loaded...  ", $records);
    }



// get data for home page in app cusa

public function main(Request $request)
{
	
	  
   $categories = Category::with("subCategories")
    
    ->where("activity",1)->orderBy("num","asc")->get();
  // $categories = Category::with("subCategories")->with(["items" => function ($q)  use ($request) {
  //  $q->with(["sizes" => function ($q)  use ($request) {
      //  $q->with("colors");
  //  }])->with("images") ;
//}])
    
   //->where("activity",1)->orderBy("num","asc")->get();

    $countries  =  Country::where("activity",1)->orderBy("num","desc")->get();
	 $settings  =  Setting::find(2);
    $sliders  =  Slider::where("activity",1)->orderBy("num","asc")->get();
	 $slashes  =  Slashe::where("activity",1)->orderBy("num","asc")->get();
    $brands  =  Brand::where("activity",1)->orderBy("num","asc")->get();

    $new  =  Item::where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)   {
        $q->with("colors");
    }])->with("images")
    ->where("new",1)->limit(5)->get();

    $popular  =  Item::where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)   {
        $q->with("colors");
    }])->with("images")
    ->where("popular",1)->limit(5)->get();

    $over  =  Item::where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)   {
        $q->with("colors");
    }])->with("images")
    ->where("over",1)->limit(5)->get();
  

    return get_response("1", "جاري التحميل",[
        "categories"=>$categories, 

        "sliders"=>$sliders , 
		"images"=>$slashes , 
        "brands"=>$brands,
        "over"=>$over,
        "popular"=>$popular,
        "new"=>$new,
		"countries"=>$countries,
		"settings"=>$settings,
       
    ]);
}

	
	/////////////////////////////////////////////////////////////////////////////
public function vendors()
{
		    $vendors  =  Vendor::where("activity",1)->orderBy("num","desc")->get();
 return get_response("1", "جاري التحميل",$vendors);
}
	
	
	
	
	/////////////////////////////////////////////////////////////////////////////
public function check_orders(Request $request)
{
    $phone = $request->phone;
    $city = $request->city;
    $name = $request->name;
    $address = $request->address;
    $price = $request->price +  $request->total;
    $token =$request->token;
    $user_id =$request->user_id;

    $cart = Cart::where("token",$token)->get();
   
   if($cart->count() > 0){
    

    foreach($cart as $one ){
        $name =Item::find( $one->item_id)->name ;

        if($one->type ==2){
            $stock = Item::find($one->item_id)->qut??0 ;
            if( $stock==0){
                return get_response("4", " المنتج $name  لم يعد متوفر الان لتتمكن من اتمام الطلب   قم بحذفه من العربة   ويسعدنا اختيارك لمنتج اخر",$stock);
        
            }
        
            if ($stock < $one->qut ){
                return get_response("4", "المنتج $name  كميته الان  $stock  قطعة فقط  لتتمكن من اتمام الشراء ارجع للعربة وعدل الكمية منه",$stock);
        
        
            }
        }else{

            $stock = Color::where("item_id", $one->item_id)->where("name",$one->color)->where("size",$one->size)->count();

            if( $stock==0){
                return get_response("4", " المنتج $name  لم يعد متوفر الان لتتمكن من اتمام الطلب   قم بحذفه من العربة   ويسعدنا اختيارك لمنتج اخر",$stock);
        
            }
        
            if ($stock < $one->qut ){
                return get_response("4", "المنتج $name  كميته الان  $stock  قطعة فقط  لتتمكن من اتمام الشراء ارجع للعربة وعدل الكمية منه",$stock);
        
        
            }


        }

       
	}
    }
	     return get_response("1"," "," " );
   }
	
	
	
	
	

/////////////////////////////////////////////////////////////////////////////
public function add_orders(Request $request)
{
    $phone = $request->phone;
    $city = $request->city;
    $name = $request->name;
    $address = $request->address;
    $price = $request->price +  $request->total;
    $token =$request->token;
    $user_id =$request->user_id;

    $cart = Cart::where("token",$token)->get();
   
   if($cart->count() > 0){
    

  

    $create_order = Order::create([
        "govern"=>$request->name ,
		 "country"=>$request->country ,
        "city"=>$request->city ,
        "phone"=>$request->phone ,
        "address"=>$request->address ,
        "price"=> $price ,
        "token"=>$token ,
		  "type"=>$request->type  ,
		  "inovic_id"=>$request->inovic_id  ,
        "balance"=>$request->balance ,
        "username"=>$request->username ,

        "user_id"=>$user_id,
        "status"=> 1,


    ]);

    foreach($cart as $one ){
        $item_one = Item::find($one->item_id) ;
        $item_price = $item_one ->over_price ;
        $item_img = $item_one ->img ;
        $item_create = OrderItem::create([
            
        "color"=>$one->color ,
        "type"=>$one->type ,
        "size"=>$one->size ,
        "qut"=>$one->qut ,
        "item_id"=>$one->item_id ,
        "price"=> $item_price ,
        "img"=>$item_img ,
        "order_id"=>$create_order->id ,
        "token"=>$token ,
        "user_id"=>$user_id ,
        



        ]);
        if($item_create){
            $one->delete();
            if($one->type ==2){
                $row=  Item::find($one->item_id);
                      $update=   $row->update([
                          "qut"=>$row->qut - $one->qut
                      ]);

            

            }else{
                $item_del_found = Color::where("name",$one->color)->where("size",$one->size)->where("item_id",$one->item_id)->first();
				if($item_del_found){
					 $item_del = $item_del_found->delete();

				}

            }

        }

    }

    if($item_create){

        $row = Client::where("api_token",$token)->first();

        if($row){
            $balance = $row->balance;
            $row->update([
                "balance"=> ( $balance - $request->balance) 
            ]);
        }
		$noti_db = \App\Models\Notification::create([
				"title"=>"new order",
			"description"=>" لديك طلب جديد راجع لوحة التحكم" ,
			"type"=>"order"
			]
			
		);
		
		  Mail::to("moha228830@gmail.com")

                    ->bcc("moha228830@gmail.com")
                   ->send(new reset_password("no"));
        return get_response("1", "تمت العملية بنجاح ", "" );

    }else{
        return get_response("0", "حاول مرة اخري", "error1" );

    }

}else{
    return get_response("0", "حاول مرة اخري", "error2" );

}



  

}

///////////////////////////////////////////////////////////////////////////////////
public function home_products(Request $request)
{
    if($request->id  and $request->type ){
           
        
        

           if($request->type=="sliders" ){
// if is brands products 
               $records = Items::where("tags",$request->id)->where("activity",1)->orderBy("num","asc")->get();
    
           }
           if($request->type=="brands" ){
 // if is sliders products   
              $records = Items::where("brand_id",$request->id)->where("activity",1)->orderBy("num","asc")->get();
 
          }else{
//error in route 


        return get_response("0", "error 400", "error" );
          }

   

    }else{
 //error in route 
        return get_response("0", "error 400", "error" );

    }
}




//////////////////////////////////////////////////////////////////////////////////
public function items(Request $request)
{
    //request has ids and type
      if($request->sub_id  and $request->type ){
           
        $subsub = SubSubCategory::where("subCategory_id" ,$request->sub_id)->where("activity",1)->orderBy("num","asc")->get();
		  
		    //////////favorite ///////////////////
		  
		    if($request->type=="favorite" ){
				
                          $all_favorite = explode(",",$request->favorite);
			             	//dd($all_favorite);
                           $records = Item::whereIn("id",$all_favorite)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }

		  
		  //////////////////end favorite 
		  
		  
		  


        if($request->type=="over" ){
            // if is brands products 
                           $records = Item::where("over",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }


                       if($request->type=="popular" ){
                        // if is brands products 
                                       $records = Item::where("popular",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)->get();
            
                                       if(  $records) {
            
                                        return get_response("1", "جاري التحميل",[
                                            "subsub"=>$subsub, 
                                    
                                            "items"=>$records , 
                                            
                                        ]);
            
                                    }else{
            
            
                                        return get_response("0", "error 400", "error" );
            
                                    }
                            
                                   }



                                   if($request->type=="new" ){
                                    // if is brands products 
                                                   $records = Item::where("new",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                                    $q->with("colors");
                                                }])->with("images")
                                                    ->limit($request->page??10)->offset($request->offset??0)->get();
                        
                                                   if(  $records) {
                        
                                                    return get_response("1", "جاري التحميل",[
                                                        "subsub"=>$subsub, 
                                                
                                                        "items"=>$records , 
                                                        
                                                    ]);
                        
                                                }else{
                        
                        
                                                    return get_response("0", "error 400", "error" );
                        
                                                }
                                        
                                               }



        if($request->type=="sliders" ){
            // if is brands products 
                           $records = Item::where("tags",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }
		  
		    if($request->type=="all" ){
            // if is brands products 
                           $records = Item::where("category_id",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }
                       if($request->type=="brands" ){
             // if is sliders products   
                          $records = Item::where("brand_id",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();
                          if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
             
                      }



                        if ($request->type == "sub"){
                             //  get items by sub category  
   
                              


                                     $items = Item::query();
							
				
if ($request->filled('sub_sub_id')) //checks if the parameter is exists and not empty
{  
$items->where('subSubCategory_id',$request->sub_sub_id); 
}



if ($request->filled('type_id') && $request->type_id ==1)
{
$items->orderBy('over_price','asc');
}
	else if ($request->filled('type_id') && $request->type_id ==2)
{
$items->orderBy('over_price','desc');
}
		 else if ($request->filled('type_id') && $request->type_id ==3)
{
$items->orderBy('popular','desc');
}else if ($request->filled('type_id') && $request->type_id ==4)
{
$items->orderBy('new','desc');
}else if ($request->filled('type_id') && $request->type_id ==5)
{
$items->orderBy('over','desc');
}
		  else{
    $items->orderBy("num","asc");

}	  
							
		 	if ($request->keyword &&  trim($request->keyword) !="" ){
   $items->where('name' , 'like','%' .$request->keyword.'%' )
	   ->orWhere('description' , 'like','%' .$request->keyword.'%' );
				
			 $items = $items->where("activity",1)->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)
										 ->get();
   
}	else{
			 $items = $items->where("subCategory_id",$request->sub_id)->where("activity",1)->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)
										 ->get();	
			}				
		 

                                                if(  $items) {

                                                    return get_response("1", "جاري التحميل",[
                                                        "subsub"=>$subsub, 
                                                
                                                        "items"=>$items , 
                                                        
                                                    ]);

                                                }else{


                                                    return get_response("0", "error 400", "error" );

                                                }


                        }else{

                        
							
	   $items = Item::query();
							
				
if ($request->filled('sub_sub_id')) //checks if the parameter is exists and not empty
{  
$items->where('subSubCategory_id',$request->sub_sub_id); 
}



if ($request->filled('type_id') && $request->type_id ==1)
{
$items->orderBy('over_price','asc');
}
	else if ($request->filled('type_id') && $request->type_id ==2)
{
$items->orderBy('over_price','desc');
}
		 else if ($request->filled('type_id') && $request->type_id ==3)
{
$items->orderBy('popular','desc');
}else if ($request->filled('type_id') && $request->type_id ==4)
{
$items->orderBy('new','desc');
}else if ($request->filled('type_id') && $request->type_id ==5)
{
$items->orderBy('over','desc');
}
		  else{
    $items->orderBy("num","asc");

}	  
							
		 	if ($request->keyword &&  trim($request->keyword) !="" ){
   $items->where('name' , 'like','%' .$request->keyword.'%' )
	   ->orWhere('description' , 'like','%' .$request->keyword.'%' );
				
			 $items = $items->where("activity",1)->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)
										 ->get();
   
}	else{
			 $items = $items->where("subSubCategory_id",$request->sub_id)->where("activity",1)->with(["sizes" => function ($q)  use ($request) {
                                                                        $q->with("colors");
                                                                    }])->with("images")
                                                                    ->limit($request->page??10)->offset($request->offset??0)->get();
							
			}							
							
							
							
							
                                                      // get items by sub sub   category 

  
							
							
          if(  $items) {

      return get_response("1", "جاري التحميل",[
              "subsub"=>$subsub, 
                                                                    
              "items"=>$items , 
                                                                            
                  ]);

                                                                    }else{


                                                                        return get_response("0", "error 400", "error" );

                                                                    }
                                              



                        }


      }else{
          // faild in request data
          return get_response("0", "error 404", "error" );

      }
}




///////////////////////////////get my orders //////////////////////////////////

public function my_orders (Request $request){
 $token = $request->token ;
 $user_id = $request->user_id ; 

 $records = Order::where("token",$token)->orderBy("id","desc")->get();
 if( $records){
	  // Mail::to("moha228830@gmail.com")

                 //   ->bcc("moha228830@gmail.com")
                  //  ->send(new reset_password($records));
    return get_response("1", "load",$records);   
	

 }
 // 2- cart not has items
 else{
    return get_response("0", "error E1_2", "error" );


 }

}





///////////////////////////////get cart items //////////////////////////////////

public function get_carts (Request $request){
  
    //errprs ====> 1  
     $token =  $request->token ;
     $user_id =  $request->user_id ;

     /// when not send token =============> give error 

     if( $token==false ){
        return get_response("0", "error E1_1", "error" );

     }


     $records  = Cart::where("token",$token)->orderBy("id","desc")->get();

     // check if cart has items


     //  1- the cart has items
     if( $records){
        return get_response("1", "load",$records);

     }
     // 2- cart not has items
     else{
        return get_response("0", "error E1_2", "error" );


     }







}




///////////////////////////////get cart items //////////////////////////////////

public function get_governs (Request $request){
  
   

    /// when not send token =============> give error 

   
 $balance =0.0;
   // $records  = Country::with("governs")->orderBy("num","desc")->get();
 $records  = Govern::orderBy("num","desc")->get();
    $row  = Client::where("api_token",$request->token)->first() ;

    if( $row ){
          $balance = $row->balance ;
             
    }

    // check if cart has items


    //  1- the cart has items
    if( $records){
       return get_response("1", $balance,$records);

    }
    // 2- cart not has items
    else{
       return get_response("0", "error E1_2", "error" );


    }







}



public function add_carts (Request $request){

    if($request->type ==2){

        
        $token = $request->token ; 
        $qut = $request->qut ; 
        $item_id = $request->item_id ; 

    
        $messeges = [
    
           
            'token.required'=>" اكمل اليانات",
            'qut.required'=>" اكمل اليانات",
            'item_id.required'=>" اكمل اليانات",
    
           ];
    
    
        $validator =  Validator::make($request->all(), [
    
            
            "token"=>"required",
            'qut' => 'required',
            'item_id' => 'required',
          
    
        ], $messeges);
    
    
    
        if ($validator->fails()) {
            return get_response("2", "اكمل اليانات", $validator->errors());
        }
    
        // check if qut > stock or not  
    
        $stock = Item::find($item_id)->qut??0 ;
    
        if( $stock==0){
            return get_response("4", "نظرا للطلب الكبير علي المنتج نعتذر عن نفاذ الكمية الان سنوفر لك المنتج في اسرع وقت ",$stock);
    
        }
    
        if ($stock < $qut ){
            return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
    
    
        }
    
          // if item alerdy added
    
          $ch = Cart::where("item_id",$item_id)->where("token",$token)->count();
    
          if($ch > 0){
    
            $data = Cart::where("item_id",$item_id)->where("token",$token)->first();
            $qut_old = $data->qut;
    
            if ($stock < $qut_old  +  $qut ){
                return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
        
        
            }
            
            if($qut_old  +  $qut  > 50){
                return get_response("4", "الحد الاقصي لطلب المنتج هو 50 قطعة" ,"" );
    
            }
    
            $update = $data ->update([
                "qut"=> $qut_old  +  $qut 
    
                
            ]);
    
            if($update){
				$co = Cart::where("token",$request->token)->count();
                return get_response("1", "load",$co);
    
            }else{
                return get_response("0", "error E2_3", "error" );
            }
    
    
          }else{
            $record = Cart::create($request->all());
    
            if ($record){
			$co = Cart::where("token",$request->token)->count();

                return get_response("1", "load",$co);
        
            }else{
                return get_response("0", "error E2_2", "error" );
        
        
            }
          }
    
      

        //////////////////////////////////////////////////////////////////////////////////////////////
        ///////////////////////////////////////////////////////////////////////////////////////////
        //////////////////////////////////////////////////////////////////////////////////////////////
      
    }else{

        $color = $request->color ; 
        $size = $request->size ; 
        $token = $request->token ; 
        $qut = $request->qut ; 
        $item_id = $request->item_id ; 
    
        $messeges = [
    
            'color.required'=>"اكمل اليانات",
            'size.required'=>"اكمل اليانات",
            'token.required'=>" اكمل اليانات",
            'qut.required'=>" اكمل اليانات",
            'item_id.required'=>" اكمل اليانات",
    
           ];
    
    
        $validator =  Validator::make($request->all(), [
    
            'color' => 'required',
            'size' => 'required',
            "token"=>"required",
            'qut' => 'required',
            'item_id' => 'required',
    
        ], $messeges);
    
    
    
        if ($validator->fails()) {
            return get_response("2", "اكمل اليانات", $validator->errors());
        }
    
    
        // check if qut > stock or not  
    
        $stock = Color::where("item_id",$item_id)->where("name",$color)->where("size",$size)->count();
    
        if( $stock==0){
            return get_response("4", "نظرا للطلب الكبير علي المنتج نعتذر عن نفاذ الكمية الان سنوفر لك المنتج في اسرع وقت ",$stock);
    
        }
    
        if ($stock < $qut ){
            return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
    
    
        }
    
          // if item alerdy added
    
          $ch = Cart::where("item_id",$item_id)->where("color",$color)->where("size",$size)->where("token",$token)->count();
    
          if($ch > 0){
    
            $data = Cart::where("item_id",$item_id)->where("color",$color)->where("size",$size)->where("token",$token)->first();
            $qut_old = $data->qut;
    
            if ($stock < $qut_old  +  $qut ){
                return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
        
        
            }
            
            if($qut_old  +  $qut  > 50){
                return get_response("4", "الحد الاقصي لطلب المنتج هو 50 قطعة" ,"" );
    
            }
    
            $update = $data ->update([
                "qut"=> $qut_old  +  $qut 
    
                
            ]);
    
            if($update){
			$co = Cart::where("token",$request->token)->count();

                return get_response("1", "load",$co);
    
            }else{
                return get_response("0", "error E2_3", "error" );
            }
    
    
          }else{
            $record = Cart::create($request->all());
    
            if ($record){
								$co = Cart::where("token",$request->token)->count();

                return get_response("1", "load",$co);
        
            }else{
                return get_response("0", "error E2_2", "error" );
        
        
            }
          }
    
      


    }

   



    


 
}







public function add_carts_cart (Request $request){
   

    if($request->type == 2)
    {

     
        $token = $request->token ; 
        $qut = $request->qut ; 
        $item_id = $request->item_id ; 
    
        $messeges = [
    
            'token.required'=>" اكمل اليانات",
            'qut.required'=>" اكمل اليانات",
            'item_id.required'=>" اكمل اليانات",
    
           ];
    
    
        $validator =  Validator::make($request->all(), [
    
            
            "token"=>"required",
            'qut' => 'required',
            'item_id' => 'required',
    
        ], $messeges);
    
    
    
        if ($validator->fails()) {
            return get_response("2", "اكمل اليانات", $validator->errors());
        }
    
    
        // check if qut > stock or not  
    
        $stock = Item::find($item_id)->qut??0 ;
    
        if( $stock==0){
            return get_response("4", "نظرا للطلب الكبير علي المنتج نعتذر عن نفاذ الكمية الان سنوفر لك المنتج في اسرع وقت ",$stock);
    
        }
    
        if ($stock < $qut ){
            return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
    
    
        }
    
          // if item alerdy added
    
          $ch = Cart::where("item_id",$item_id)->where("token",$token)->count();
    
          if($ch > 0){
    
            $data = Cart::where("item_id",$item_id)->where("token",$token)->first();
            
            if(  $qut  > 50){
                return get_response("4", "الحد الاقصي لطلب المنتج هو 50 قطعة" ,"" );
    
            }
    
            $update = $data ->update([
                "qut"=>   $qut 
    
                
            ]);
    
            if($update){
                return get_response("1", "load","");
    
            }else{
                return get_response("0", "error E2_3", "error" );
            }
    
    
          }else{
            return get_response("0", "error E2_3", "error" );
    
          }

        //////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////////////////////////////////////////
    }else{
        $color = $request->color ; 
        $size = $request->size ; 
        $token = $request->token ; 
        $qut = $request->qut ; 
        $item_id = $request->item_id ; 
    
        $messeges = [
    
            'color.required'=>"اكمل اليانات",
            'size.required'=>"اكمل اليانات",
            'token.required'=>" اكمل اليانات",
            'qut.required'=>" اكمل اليانات",
            'item_id.required'=>" اكمل اليانات",
    
           ];
    
    
        $validator =  Validator::make($request->all(), [
    
            'color' => 'required',
            'size' => 'required',
            "token"=>"required",
            'qut' => 'required',
            'item_id' => 'required',
    
        ], $messeges);
    
    
    
        if ($validator->fails()) {
            return get_response("2", "اكمل اليانات", $validator->errors());
        }
    
    
        // check if qut > stock or not  
    
        $stock = Color::where("item_id",$item_id)->where("name",$color)->where("size",$size)->count();
    
        if( $stock==0){
            return get_response("4", "نظرا للطلب الكبير علي المنتج نعتذر عن نفاذ الكمية الان سنوفر لك المنتج في اسرع وقت ",$stock);
    
        }
    
        if ($stock < $qut ){
            return get_response("4", "عذرا الكمية المتوفرة لدينا حالية  $stock  قطعة فقط من هذه المواصفات للون والمقاس   ",$stock);
    
    
        }
    
          // if item alerdy added
    
          $ch = Cart::where("item_id",$item_id)->where("color",$color)->where("size",$size)->where("token",$token)->count();
    
          if($ch > 0){
    
            $data = Cart::where("item_id",$item_id)->where("color",$color)->where("size",$size)->where("token",$token)->first();
            
            if(  $qut  > 50){
                return get_response("4", "الحد الاقصي لطلب المنتج هو 50 قطعة" ,"" );
    
            }
    
            $update = $data ->update([
                "qut"=>   $qut 
    
                
            ]);
    
            if($update){
                return get_response("1", "load","");
    
            }else{
                return get_response("0", "error E2_3", "error" );
            }
    
    
          }else{
            return get_response("0", "error E2_3", "error" );
    
          }
    }
   

  
  



    


 
}





public function delet_from_cart (Request $request){

    $token  = $request->token ;
    $id = $request->id ;

    $messeges = [

        'id.required'=>"المنتج مطلوب",
        'token.required'=>"التوكن مطلوب",
       

       ];


    $validator =  Validator::make($request->all(), [

        'id' => 'required',
        'token' => 'required',
       

    ], $messeges);



    if ($validator->fails()) {
        return get_response("0", "خطأ غير متوقع  اغلق التطبيق واعد فتحه", $validator->errors());
    }


    $record = Cart::find($id);

    if(Cart::where("id",$id)->count() == 0){
        return get_response("0", "خطأ غير متوقع  اغلق التطبيق واعد فتحه", "");

    }
   
   $delete =  $record->delete();

   if ($delete){
       				$co = Cart::where("token",$request->token)->count();

    return get_response("1", "تمت العملية بنجاح", $co);

   }

        return get_response("0", "خطأ غير متوقع  اغلق التطبيق واعد فتحه", "");





    }
     

     
























































public function get_governs_v2 (Request $request){
  
   

    /// when not send token =============> give error 

   
 $balance =0.0;
    $records  = Country::with("governs")->orderBy("num","desc")->get();
// $records  = Govern::orderBy("num","desc")->get();
    $row  = Client::where("api_token",$request->token)->first() ;

    if( $row ){
          $balance = $row->balance ;
             
    }

    // check if cart has items


    //  1- the cart has items
    if( $records){
       return get_response("1", $balance,$records);

    }
    // 2- cart not has items
    else{
       return get_response("0", "error E1_2", "error" );


    }







}


//////////////////////////////////////////////////////////////////////////////////
public function items_v2(Request $request)
{
    //request has ids and type
      if($request->sub_id  and $request->type ){
           
        $subsub = SubSubCategory::where("subCategory_id" ,$request->sub_id)->where("activity",1)->query();
		  
	if ($request->filled('keyword')){
    $q->where('name' , 'like','%' .$request->keyword.'%' )->orWhere('description' , 'like','%' .$request->keyword.'%' );
   
}
if ($request->filled('sub_sub_id')) //checks if the parameter is exists and not empty
{  
$q->where('subSubCategory_id',$request->sub_sub_id); 
}



if ($request->filled('type_id') && $request->type_id ==1)
{
$q->orderBy('price','asc');
}
	else if ($request->filled('type_id') && $request->type_id ==2)
{
$q->orderBy('price','desc');
}
		  else if ($request->filled('type_id') && $request->type_id ==3)
{
$q->orderBy('new','desc');
}else if ($request->filled('type_id') && $request->type_id ==4)
{
$q->orderBy('popular','desc');
}else if ($request->filled('type_id') && $request->type_id ==5)
{
$q->orderBy('popular','desc');
}
		  else{
    $q->orderBy("num","asc");

}	  
		  







        if($request->type=="over" ){
            // if is brands products 
                           $records = Item::where("over",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }


                       if($request->type=="popular" ){
                        // if is brands products 
                                       $records = Item::where("popular",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)->get();
            
                                       if(  $records) {
            
                                        return get_response("1", "جاري التحميل",[
                                            "subsub"=>$subsub, 
                                    
                                            "items"=>$records , 
                                            
                                        ]);
            
                                    }else{
            
            
                                        return get_response("0", "error 400", "error" );
            
                                    }
                            
                                   }



                                   if($request->type=="new" ){
                                    // if is brands products 
                                                   $records = Item::where("new",1)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                                    $q->with("colors");
                                                }])->with("images")
                                                    ->limit($request->page??10)->offset($request->offset??0)->get();
                        
                                                   if(  $records) {
                        
                                                    return get_response("1", "جاري التحميل",[
                                                        "subsub"=>$subsub, 
                                                
                                                        "items"=>$records , 
                                                        
                                                    ]);
                        
                                                }else{
                        
                        
                                                    return get_response("0", "error 400", "error" );
                        
                                                }
                                        
                                               }



        if($request->type=="sliders" ){
            // if is brands products 
                           $records = Item::where("tags",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }
		  
		    if($request->type=="all" ){
            // if is brands products 
                           $records = Item::where("category_id",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();

                           if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
                
                       }
                       if($request->type=="brands" ){
             // if is sliders products   
                          $records = Item::where("brand_id",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                            $q->with("colors");
                        }])->with("images")
                            ->limit($request->page??10)->offset($request->offset??0)->get();
                          if(  $records) {

                            return get_response("1", "جاري التحميل",[
                                "subsub"=>$subsub, 
                        
                                "items"=>$records , 
                                
                            ]);

                        }else{


                            return get_response("0", "error 400", "error" );

                        }
             
                      }



                        if ($request->type == "sub"){
                             //  get items by sub category  
   
                              


                                     $items = Item::where("subCategory_id",$request->sub_id)->where("activity",1)->orderBy("num","asc")->with("sizes")->with(["sizes" => function ($q)  use ($request) {
                                        $q->with("colors");
                                    }])->with("images")
                                        ->limit($request->page??10)->offset($request->offset??0)->get();

                                                if(  $items) {

                                                    return get_response("1", "جاري التحميل",[
                                                        "subsub"=>$subsub, 
                                                
                                                        "items"=>$items , 
                                                        
                                                    ]);

                                                }else{


                                                    return get_response("0", "error 400", "error" );

                                                }


                        }else{

                                             
                                                      // get items by sub sub   category 

                                                                    $items = Item::where("subSubCategory_id",$request->sub_id)->where("activity",1)->with(["sizes" => function ($q)  use ($request) {
                                                                        $q->with("colors");
                                                                    }])->with("images")
                                                                    ->limit($request->page??10)->offset($request->offset??0)->get();
                                                                    if(  $items) {

                                                                        return get_response("1", "جاري التحميل",[
                                                                            "subsub"=>$subsub, 
                                                                    
                                                                            "items"=>$items , 
                                                                            
                                                                        ]);

                                                                    }else{


                                                                        return get_response("0", "error 400", "error" );

                                                                    }
                                              



                        }


      }else{
          // faild in request data
          return get_response("0", "error 404", "error" );

      }
}




    
   


}
