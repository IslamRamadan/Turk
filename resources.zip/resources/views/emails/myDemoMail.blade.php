@component('mail::message')


new order.

@component('mail::button', ['url' => ''])
لديك طلب جديد راجع لوحة التحكم
@endcomponent
Thanks,<br>

@endcomponent
