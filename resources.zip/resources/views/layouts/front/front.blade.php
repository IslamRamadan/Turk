@include('layouts.front.header')



@yield('content')



@include('layouts.front.footer')